// ../packages/contracts/dist/index.js
var CONTRACT_VERSION = 1;
var MODEL_PROVIDER = "deepseek";
var MODEL_NAME = "deepseek-flash";
function isRecord(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

// src/discovery/summary.ts
function summarizeDiscovery(checkpoint2) {
  const contentPages = checkpoint2.visitedPageUrls.filter(
    (value) => new URL(value).pathname.endsWith("/children")
  );
  const announcementPages = checkpoint2.visitedPageUrls.filter(
    (value) => new URL(value).pathname.endsWith("/announcements")
  );
  const contentDetails = checkpoint2.visitedPageUrls.filter(
    (value) => /\/contents\/[^/]+$/.test(new URL(value).pathname)
  );
  const pagePathCounts = /* @__PURE__ */ new Map();
  for (const value of checkpoint2.visitedPageUrls) {
    const pathname = new URL(value).pathname;
    pagePathCounts.set(pathname, (pagePathCounts.get(pathname) ?? 0) + 1);
  }
  const contentSources = checkpoint2.sources.filter(
    (source) => source.kind === "course-content-item" || source.kind === "assignment"
  );
  const attachmentSources2 = checkpoint2.sources.filter((source) => source.kind === "attachment");
  const attachmentOrigins = [
    ...new Set(
      attachmentSources2.flatMap(
        (source) => source.requestUrl ? [new URL(source.requestUrl).origin] : []
      )
    )
  ].sort();
  return {
    detailCoverageComplete: Array.isArray(checkpoint2.visitedDetailItemIds),
    complete: checkpoint2.complete,
    sourceCount: checkpoint2.sources.length,
    issueCount: checkpoint2.issues.length,
    contentPageCount: contentPages.length,
    contentDetailCount: contentDetails.length,
    announcementPageCount: announcementPages.length,
    paginationDetected: [...pagePathCounts.values()].some((count) => count > 1),
    contentMaxDepth: contentSources.reduce((maximum, source) => Math.max(maximum, source.depth), 0),
    contentItemCount: contentSources.length,
    assignmentCount: checkpoint2.sources.filter((source) => source.kind === "assignment").length,
    announcementCount: checkpoint2.sources.filter((source) => source.kind === "announcement").length,
    attachmentCount: attachmentSources2.length,
    attachmentOrigins,
    attachmentsMissingRequestUrl: attachmentSources2.filter((source) => !source.requestUrl).length
  };
}

// src/repository/course-index-repository.ts
var COURSE_INDEX_KEY = "syllab.courseIndex";
var SCAN_SUMMARIES_KEY = "syllab.scanSummaries";
function readArray(value) {
  return Array.isArray(value) ? value : [];
}
var CourseIndexRepository = class {
  constructor(storage) {
    this.storage = storage;
  }
  async listCourses() {
    const result = await this.storage.get(COURSE_INDEX_KEY);
    return readArray(result[COURSE_INDEX_KEY]);
  }
  async findCourse(courseId) {
    const courses = await this.listCourses();
    return courses.find((course) => course.courseId === courseId) ?? null;
  }
  async findCourseByScanFallback(scanId) {
    const scans = await this.listScans();
    const scan = scans.find((item) => item.scanId === scanId);
    return scan ? this.findCourse(scan.courseId) : null;
  }
  async upsertCourse(course) {
    const courses = await this.listCourses();
    await this.storage.set({
      [COURSE_INDEX_KEY]: [course, ...courses.filter((item) => item.courseId !== course.courseId)]
    });
  }
  async findEntryScan(courseId) {
    const result = await this.storage.get(SCAN_SUMMARIES_KEY);
    const scans = readArray(result[SCAN_SUMMARIES_KEY]);
    return scans.find(
      (scan) => scan.courseId === courseId && (scan.status === "Scanning" || scan.status === "WaitingForPermission" || scan.status === "Interrupted" && scan.recoverable)
    ) ?? null;
  }
  async listScans() {
    const result = await this.storage.get(SCAN_SUMMARIES_KEY);
    return readArray(result[SCAN_SUMMARIES_KEY]);
  }
  async replaceScans(scans) {
    await this.storage.set({ [SCAN_SUMMARIES_KEY]: structuredClone(scans) });
  }
  async resumeScan(scanId) {
    const scans = await this.listScans();
    const target = scans.find((scan) => scan.scanId === scanId);
    if (!target || target.status !== "Interrupted" || !target.recoverable) return null;
    const resumed = { ...target, status: "Scanning", recoverable: true };
    await this.replaceScans(scans.map((scan) => scan.scanId === scanId ? resumed : scan));
    return resumed;
  }
};

// src/repository/discovery-repository.ts
var DISCOVERY_CHECKPOINTS_KEY = "syllab.discoveryCheckpoints";
var DiscoveryRepository = class {
  constructor(storage) {
    this.storage = storage;
  }
  async getCheckpoint(scanId) {
    const current = await this.storage.get(DISCOVERY_CHECKPOINTS_KEY);
    const records = current[DISCOVERY_CHECKPOINTS_KEY];
    if (typeof records !== "object" || records === null || Array.isArray(records)) return void 0;
    return records[scanId];
  }
  async findRecoverableDiscovery(courseId) {
    const current = await this.storage.get([SCAN_SUMMARIES_KEY, DISCOVERY_CHECKPOINTS_KEY]);
    const scans = Array.isArray(current[SCAN_SUMMARIES_KEY]) ? current[SCAN_SUMMARIES_KEY] : [];
    const summary = scans.find(
      (scan) => scan.courseId === courseId && scan.status === "Scanning" && scan.recoverable && scan.phase === "discovery"
    );
    if (!summary) return null;
    const records = current[DISCOVERY_CHECKPOINTS_KEY];
    if (typeof records !== "object" || records === null || Array.isArray(records)) return null;
    const checkpoint2 = records[summary.scanId];
    return checkpoint2 && !checkpoint2.complete ? { summary, checkpoint: checkpoint2 } : null;
  }
  async saveCheckpoint(checkpoint2) {
    const current = await this.storage.get(DISCOVERY_CHECKPOINTS_KEY);
    const records = typeof current[DISCOVERY_CHECKPOINTS_KEY] === "object" && current[DISCOVERY_CHECKPOINTS_KEY] !== null && !Array.isArray(current[DISCOVERY_CHECKPOINTS_KEY]) ? current[DISCOVERY_CHECKPOINTS_KEY] : {};
    await this.storage.set({
      [DISCOVERY_CHECKPOINTS_KEY]: { ...records, [checkpoint2.scanId]: checkpoint2 }
    });
  }
  async upsertScanSummary(summary) {
    const current = await this.storage.get(SCAN_SUMMARIES_KEY);
    const scans = Array.isArray(current[SCAN_SUMMARIES_KEY]) ? current[SCAN_SUMMARIES_KEY] : [];
    const next = scans.filter((scan) => scan.scanId !== summary.scanId);
    next.unshift(summary);
    await this.storage.set({ [SCAN_SUMMARIES_KEY]: next });
  }
  async getScanSummary(scanId) {
    const current = await this.storage.get(SCAN_SUMMARIES_KEY);
    const scans = Array.isArray(current[SCAN_SUMMARIES_KEY]) ? current[SCAN_SUMMARIES_KEY] : [];
    return scans.find((scan) => scan.scanId === scanId);
  }
};

// src/shared/storage-schema.ts
var STORAGE_SCHEMA_VERSION = 1;
var STORAGE_SCHEMA_VERSION_KEY = "syllab.schemaVersion";

// src/repository/schema-repository.ts
async function ensureStorageSchema(storage) {
  const current = await storage.get(STORAGE_SCHEMA_VERSION_KEY);
  const storedVersion = current[STORAGE_SCHEMA_VERSION_KEY];
  if (storedVersion === void 0) {
    const metadata = {
      [STORAGE_SCHEMA_VERSION_KEY]: STORAGE_SCHEMA_VERSION
    };
    await storage.set({ ...metadata });
    return metadata;
  }
  if (storedVersion !== STORAGE_SCHEMA_VERSION) {
    throw new Error(`Unsupported storage schema version: ${JSON.stringify(storedVersion)}`);
  }
  return { [STORAGE_SCHEMA_VERSION_KEY]: STORAGE_SCHEMA_VERSION };
}
async function readStorageSchemaVersion(storage) {
  const result = await storage.get(STORAGE_SCHEMA_VERSION_KEY);
  const version = result[STORAGE_SCHEMA_VERSION_KEY];
  if (typeof version !== "number") throw new Error("Storage schema has not been initialized");
  return version;
}

// src/discovery/domain.ts
var DiscoveryApiError = class extends Error {
  constructor(message, status) {
    super(message);
    this.status = status;
    this.name = "DiscoveryApiError";
  }
};

// src/discovery/engine.ts
var collectionKeys = ["results", "items", "children", "contents", "announcements"];
function cloneCheckpoint(checkpoint2) {
  return structuredClone(checkpoint2);
}
function createCheckpoint(options) {
  return {
    scanId: options.scanId,
    courseId: options.courseId,
    queue: [{ nativeItemId: "ROOT", depth: 0, discoveryPath: ["content-root"] }],
    visitedContainerIds: [],
    visitedItemIds: [],
    visitedPageUrls: [],
    detailQueue: [],
    visitedDetailItemIds: [],
    sources: [],
    issues: [],
    pagesProcessed: 0,
    announcementsComplete: false,
    complete: false
  };
}
function readCollection(payload) {
  if (Array.isArray(payload)) return Array.from(payload);
  if (!isRecord(payload)) return null;
  for (const key of collectionKeys) {
    const collection = payload[key];
    if (Array.isArray(collection)) return Array.from(collection);
  }
  return null;
}
function readNextPage(payload, baseEndpoint) {
  if (!isRecord(payload)) return null;
  const paging = isRecord(payload.paging) ? payload.paging : isRecord(payload.pagination) ? payload.pagination : null;
  const links = isRecord(payload.links) ? payload.links : null;
  const raw = paging?.nextPage ?? paging?.next ?? links?.next ?? payload.next;
  const href = typeof raw === "string" ? raw : isRecord(raw) && typeof raw.href === "string" ? raw.href : null;
  return href ? new URL(href, baseEndpoint).href : null;
}
function readString(record, keys) {
  for (const key of keys) {
    const value = record[key];
    if (typeof value === "string" && value.trim()) return value.trim();
  }
  return void 0;
}
function itemId(item) {
  return readString(item, ["id", "contentId", "content_id"]);
}
function itemTitle(item, fallback) {
  const direct = readString(item, ["title", "name", "displayName"]);
  if (direct) return direct;
  const content = isRecord(item.content) ? item.content : null;
  return (content ? readString(content, ["title", "name", "displayName"]) : void 0) ?? fallback;
}
function itemType(item) {
  const handler = item.contentHandler;
  const content = isRecord(item.content) ? item.content : null;
  const detail = isRecord(item.contentDetail) ? item.contentDetail : null;
  return [
    typeof handler === "string" ? handler : void 0,
    readString(item, ["contentHandlerId", "contentType", "type"]),
    isRecord(handler) ? readString(handler, ["id", "name"]) : void 0,
    content ? readString(content, ["contentHandlerId", "contentType", "type"]) : void 0,
    detail ? readString(detail, ["contentHandlerId", "contentType", "type"]) : void 0
  ].filter((value) => Boolean(value)).join(" ").slice(0, 160);
}
function itemKind(item) {
  return /assignment|asmt/i.test(`${itemType(item)} ${itemTitle(item, "")}`) ? "assignment" : "course-content-item";
}
function explicitlyHasChildren(item) {
  if (item.hasChildren === true || item.isFolder === true || item.isLearningModule === true)
    return true;
  const childCount = item.childCount ?? item.childrenCount;
  if (typeof childCount === "number" && childCount > 0) return true;
  if (typeof childCount === "string" && Number(childCount) > 0) return true;
  return /folder|module|container|lesson/i.test(itemType(item));
}
function shouldProbeChildren(item) {
  if (explicitlyHasChildren(item)) return true;
  if (item.hasChildren === false) return false;
  const type = itemType(item);
  if (/file|document|externallink|courselink|assignment|discussion|test/i.test(type)) return false;
  return true;
}
function canonicalAttachmentUrl(raw, origin) {
  try {
    const url = new URL(raw, origin);
    url.hash = "";
    url.search = "";
    return url.href;
  } catch {
    return void 0;
  }
}
function resolveAttachmentUrl(raw, origin) {
  try {
    return new URL(raw, origin).href;
  } catch {
    return void 0;
  }
}
function extensionHint(value) {
  if (!value) return false;
  return /\.(?:pdf|pptx?|docx?)(?:$|[?#])/i.test(value) || /\/bbcswebdav\//i.test(value);
}
function rawTextEvidence(item) {
  const keys = ["body", "description", "rawText", "renderedText", "formattedText", "text", "html"];
  for (const key of keys) {
    const value = item[key];
    if (typeof value === "string" && value.trim()) return value;
  }
  for (const key of ["content", "contentDetail", "data"]) {
    const nested = item[key];
    if (isRecord(nested)) {
      const value = rawTextEvidence(nested);
      if (value) return value;
    }
  }
  return void 0;
}
function attachmentCandidates(item) {
  const candidates = [];
  const visited = /* @__PURE__ */ new WeakSet();
  const sensitiveKey = /token|cookie|auth|session|password|user|grade|submission|attempt/i;
  const walk = (value, depth, attachmentContext) => {
    if (depth > 8 || value === null || typeof value !== "object") return;
    if (visited.has(value)) return;
    visited.add(value);
    if (Array.isArray(value)) {
      for (const entry of value) walk(entry, depth + 1, attachmentContext);
      return;
    }
    const record = value;
    const rawUrl = readString(record, [
      "url",
      "downloadUrl",
      "download_url",
      "fileUrl",
      "href",
      "permanentUrl"
    ]);
    const fileName = readString(record, ["fileName", "filename", "name", "displayName"]);
    if (rawUrl && (attachmentContext || extensionHint(fileName) || extensionHint(rawUrl))) {
      candidates.push(record);
    }
    for (const [key, entry] of Object.entries(record)) {
      if (sensitiveKey.test(key)) continue;
      if (typeof entry === "string" && /^(body|description|rawText|renderedText|formattedText|text|html)$/i.test(key)) {
        for (const match of entry.matchAll(/(?:href|src|data)\s*=\s*["']([^"']+)["']/gi)) {
          const href = match[1]?.replaceAll("&amp;", "&");
          if (href && extensionHint(href)) candidates.push({ href });
        }
        continue;
      }
      walk(entry, depth + 1, attachmentContext || /attachments?|files?/i.test(key));
    }
  };
  walk(item, 0, false);
  return candidates;
}
function addAttachments(checkpoint2, item, parent, origin) {
  for (const [index, attachment] of attachmentCandidates(item).entries()) {
    const rawUrl = readString(attachment, [
      "url",
      "downloadUrl",
      "download_url",
      "fileUrl",
      "href",
      "permanentUrl"
    ]);
    const requestUrl = rawUrl ? resolveAttachmentUrl(rawUrl, origin) : void 0;
    const canonicalUrl = rawUrl ? canonicalAttachmentUrl(rawUrl, origin) : void 0;
    const nativeId = readString(attachment, ["id", "fileId", "attachmentId"]);
    const stablePart = nativeId ?? canonicalUrl ?? `${parent.nativeItemId}:${String(index)}`;
    const sourceId = `attachment:${encodeURIComponent(parent.nativeItemId)}:${encodeURIComponent(stablePart)}`;
    if (checkpoint2.sources.some((source) => source.sourceId === sourceId)) continue;
    checkpoint2.sources.push({
      sourceId,
      courseId: checkpoint2.courseId,
      scanId: checkpoint2.scanId,
      nativeItemId: nativeId ?? stablePart,
      parentSourceId: parent.sourceId,
      kind: "attachment",
      title: readString(attachment, ["fileName", "filename", "name", "displayName"]) ?? `Attachment ${String(index + 1)}`,
      ...canonicalUrl ? { canonicalUrl } : {},
      ...requestUrl ? { requestUrl } : {},
      discoveryPath: [...parent.discoveryPath, sourceId],
      depth: parent.depth + 1,
      status: "discovered"
    });
  }
}
function validateNextPage(next, firstEndpoint) {
  const nextUrl = new URL(next);
  const firstUrl = new URL(firstEndpoint);
  if (nextUrl.origin !== firstUrl.origin || nextUrl.pathname !== firstUrl.pathname) {
    return {
      code: "OUT_OF_SCOPE_PAGINATION",
      retryable: false,
      detail: "Pagination left the allowed collection endpoint"
    };
  }
  return null;
}
function hasUnresolvedPagination(payload, accumulatedItemCount, nextPage) {
  if (nextPage || !isRecord(payload)) return false;
  const paging = isRecord(payload.paging) ? payload.paging : isRecord(payload.pagination) ? payload.pagination : null;
  const totalValue = paging?.total ?? payload.totalCount ?? payload.total;
  const total = typeof totalValue === "number" ? totalValue : Number(totalValue);
  return paging?.hasMore === true || payload.hasMore === true || Number.isFinite(total) && total > accumulatedItemCount;
}
async function checkpoint(options, state) {
  await options.onCheckpoint?.(cloneCheckpoint(state));
}
function contentEndpoint(origin, courseId, parentId) {
  return `${origin}/learn/api/v1/courses/${encodeURIComponent(courseId)}/contents/${encodeURIComponent(parentId)}/children`;
}
function contentDetailEndpoint(origin, courseId, itemIdValue) {
  return `${origin}/learn/api/v1/courses/${encodeURIComponent(courseId)}/contents/${encodeURIComponent(itemIdValue)}`;
}
async function discoverContent(options, state) {
  const visitedContainers = new Set(state.visitedContainerIds);
  const visitedItems = new Set(state.visitedItemIds);
  const maxDepth = options.maxDepth ?? 20;
  const finishParent = (nativeItemId) => {
    state.queue.shift();
    visitedContainers.add(nativeItemId);
    state.visitedContainerIds = [...visitedContainers];
  };
  while (state.queue.length > 0 && state.pagesProcessed < (options.maxPages ?? 600)) {
    const parent = state.queue[0];
    if (!parent) break;
    if (visitedContainers.has(parent.nativeItemId)) {
      state.queue.shift();
      continue;
    }
    const firstEndpoint = contentEndpoint(options.origin, options.courseId, parent.nativeItemId);
    const endpoint = parent.nextPageUrl ?? firstEndpoint;
    if (state.visitedPageUrls.includes(endpoint)) {
      state.issues.push({ code: "PAGINATION_LOOP", retryable: false, detail: firstEndpoint });
      finishParent(parent.nativeItemId);
      await checkpoint(options, state);
      continue;
    }
    let payload;
    try {
      payload = await options.api.get(endpoint);
    } catch (error) {
      if (error instanceof DiscoveryApiError && error.status === 400 && parent.nativeItemId !== "ROOT") {
        finishParent(parent.nativeItemId);
      } else {
        state.issues.push({
          ...parent.parentSourceId ? { sourceId: parent.parentSourceId } : {},
          code: "API_REQUEST_FAILED",
          retryable: true,
          detail: error instanceof Error ? error.message : "Discovery request failed"
        });
        finishParent(parent.nativeItemId);
      }
      await checkpoint(options, state);
      continue;
    }
    state.pagesProcessed += 1;
    state.visitedPageUrls.push(endpoint);
    const rawItems = readCollection(payload);
    if (!rawItems) {
      state.issues.push({ code: "INVALID_COLLECTION", retryable: false, detail: firstEndpoint });
      finishParent(parent.nativeItemId);
      await checkpoint(options, state);
      continue;
    }
    for (const rawItem of rawItems) {
      if (!isRecord(rawItem)) continue;
      const nativeItemId = itemId(rawItem);
      if (!nativeItemId) {
        state.issues.push({
          ...parent.parentSourceId ? { sourceId: parent.parentSourceId } : {},
          code: "INVALID_ITEM_ID",
          retryable: false,
          detail: "A discovered content item had no native ID"
        });
        continue;
      }
      if (visitedItems.has(nativeItemId)) continue;
      visitedItems.add(nativeItemId);
      state.visitedItemIds = [...visitedItems];
      const sourceId = `content:${nativeItemId}`;
      const source = {
        sourceId,
        courseId: options.courseId,
        scanId: options.scanId,
        nativeItemId,
        ...parent.parentSourceId ? { parentSourceId: parent.parentSourceId } : {},
        kind: itemKind(rawItem),
        ...itemType(rawItem) ? { nativeTypeHint: itemType(rawItem) } : {},
        title: itemTitle(rawItem, nativeItemId),
        discoveryPath: [...parent.discoveryPath, sourceId],
        depth: parent.depth,
        status: "discovered"
      };
      state.sources.push(source);
      addAttachments(state, rawItem, source, options.origin);
      state.detailQueue.push({ nativeItemId, sourceId });
      if (shouldProbeChildren(rawItem) && parent.depth < maxDepth) {
        state.queue.push({
          nativeItemId,
          parentSourceId: sourceId,
          depth: parent.depth + 1,
          discoveryPath: source.discoveryPath
        });
      }
    }
    parent.itemsSeen = (parent.itemsSeen ?? 0) + rawItems.length;
    const candidate = readNextPage(payload, firstEndpoint);
    const paginationIssue = candidate ? validateNextPage(candidate, firstEndpoint) : null;
    if (paginationIssue) {
      state.issues.push(paginationIssue);
      finishParent(parent.nativeItemId);
    } else if (candidate) {
      parent.nextPageUrl = candidate;
    } else if (hasUnresolvedPagination(payload, parent.itemsSeen, candidate)) {
      state.issues.push({
        ...parent.parentSourceId ? { sourceId: parent.parentSourceId } : {},
        code: "UNRESOLVED_PAGINATION",
        retryable: false,
        detail: "Collection reports more items but provides no usable next-page cursor"
      });
      finishParent(parent.nativeItemId);
    } else {
      finishParent(parent.nativeItemId);
    }
    await checkpoint(options, state);
  }
  if (state.queue.length > 0) {
    state.issues.push({
      code: "PAGE_LIMIT_REACHED",
      retryable: false,
      detail: `Discovery stopped after ${String(options.maxPages ?? 600)} API responses`
    });
    state.queue = [];
    await checkpoint(options, state);
  }
}
async function discoverContentDetails(options, state) {
  const visitedDetails = new Set(state.visitedDetailItemIds);
  const visitedContainers = new Set(state.visitedContainerIds);
  const maxDepth = options.maxDepth ?? 20;
  while (state.detailQueue.length > 0 && state.pagesProcessed < (options.maxPages ?? 600)) {
    const work = state.detailQueue.shift();
    if (!work || visitedDetails.has(work.nativeItemId)) continue;
    const endpoint = contentDetailEndpoint(options.origin, options.courseId, work.nativeItemId);
    let payload;
    try {
      payload = await options.api.get(endpoint);
      state.pagesProcessed += 1;
      state.visitedPageUrls.push(endpoint);
    } catch (error) {
      state.issues.push({
        sourceId: work.sourceId,
        code: "DETAIL_REQUEST_FAILED",
        retryable: !(error instanceof DiscoveryApiError) || error.status === void 0 || error.status >= 500,
        detail: error instanceof Error ? error.message : "Content detail request failed"
      });
      visitedDetails.add(work.nativeItemId);
      state.visitedDetailItemIds = [...visitedDetails];
      await checkpoint(options, state);
      continue;
    }
    const record = isRecord(payload) && isRecord(payload.content) ? payload.content : payload;
    if (!isRecord(record) || itemId(record) !== work.nativeItemId) {
      state.issues.push({
        sourceId: work.sourceId,
        code: "DETAIL_IDENTITY_MISMATCH",
        retryable: false,
        detail: "Content detail did not match the requested native item"
      });
    } else {
      const source = state.sources.find((candidate) => candidate.sourceId === work.sourceId);
      if (source) {
        if (itemKind(record) === "assignment") source.kind = "assignment";
        source.title = itemTitle(record, source.title);
        const nativeTypeHint = itemType(record);
        if (nativeTypeHint) source.nativeTypeHint = nativeTypeHint;
        const rawText = rawTextEvidence(record);
        if (rawText) source.rawText = rawText;
        addAttachments(state, record, source, options.origin);
        if (explicitlyHasChildren(record) && source.depth < maxDepth && !visitedContainers.has(work.nativeItemId) && !state.queue.some((item) => item.nativeItemId === work.nativeItemId)) {
          state.queue.push({
            nativeItemId: work.nativeItemId,
            parentSourceId: source.sourceId,
            depth: source.depth + 1,
            discoveryPath: source.discoveryPath
          });
        }
      }
    }
    visitedDetails.add(work.nativeItemId);
    state.visitedDetailItemIds = [...visitedDetails];
    await checkpoint(options, state);
  }
  if (state.detailQueue.length > 0) {
    state.issues.push({
      code: "PAGE_LIMIT_REACHED",
      retryable: false,
      detail: `Discovery stopped after ${String(options.maxPages ?? 600)} API responses`
    });
    state.detailQueue = [];
    await checkpoint(options, state);
  }
}
async function discoverAnnouncements(options, state) {
  if (state.announcementsComplete) return;
  const firstEndpoint = `${options.origin}/learn/api/v1/courses/${encodeURIComponent(options.courseId)}/announcements`;
  while (!state.announcementsComplete && state.pagesProcessed < (options.maxPages ?? 600)) {
    const endpoint = state.announcementsNextPageUrl ?? firstEndpoint;
    if (state.visitedPageUrls.includes(endpoint)) {
      state.issues.push({ code: "PAGINATION_LOOP", retryable: false, detail: firstEndpoint });
      state.announcementsComplete = true;
      break;
    }
    let payload;
    try {
      payload = await options.api.get(endpoint);
    } catch (error) {
      state.issues.push({
        code: "API_REQUEST_FAILED",
        retryable: true,
        detail: error instanceof Error ? error.message : "Announcement discovery failed"
      });
      state.announcementsComplete = true;
      break;
    }
    state.pagesProcessed += 1;
    state.visitedPageUrls.push(endpoint);
    const announcements = readCollection(payload);
    if (!announcements) {
      state.issues.push({ code: "INVALID_COLLECTION", retryable: false, detail: firstEndpoint });
      state.announcementsComplete = true;
      break;
    }
    for (const raw of announcements) {
      if (!isRecord(raw)) continue;
      const nativeItemId = itemId(raw);
      if (!nativeItemId) continue;
      const sourceId = `announcement:${nativeItemId}`;
      if (state.sources.some((source2) => source2.sourceId === sourceId)) continue;
      const source = {
        sourceId,
        courseId: options.courseId,
        scanId: options.scanId,
        nativeItemId,
        kind: "announcement",
        title: itemTitle(raw, nativeItemId),
        discoveryPath: ["announcements", sourceId],
        depth: 0,
        status: "discovered"
      };
      const rawText = rawTextEvidence(raw);
      if (rawText) source.rawText = rawText;
      state.sources.push(source);
      addAttachments(state, raw, source, options.origin);
    }
    const candidate = readNextPage(payload, firstEndpoint);
    const paginationIssue = candidate ? validateNextPage(candidate, firstEndpoint) : null;
    if (paginationIssue) {
      state.issues.push(paginationIssue);
      state.announcementsComplete = true;
    } else if (candidate) {
      state.announcementsNextPageUrl = candidate;
    } else {
      state.announcementsComplete = true;
      delete state.announcementsNextPageUrl;
    }
    await checkpoint(options, state);
  }
  if (!state.announcementsComplete) {
    state.issues.push({
      code: "PAGE_LIMIT_REACHED",
      retryable: false,
      detail: `Discovery stopped after ${String(options.maxPages ?? 600)} API responses`
    });
    state.announcementsComplete = true;
  }
  await checkpoint(options, state);
}
async function runDiscovery(options) {
  const state = options.checkpoint ? cloneCheckpoint(options.checkpoint) : createCheckpoint(options);
  const persistedShape = state;
  if (!Array.isArray(persistedShape.detailQueue)) state.detailQueue = [];
  if (!Array.isArray(persistedShape.visitedDetailItemIds)) state.visitedDetailItemIds = [];
  if (typeof persistedShape.announcementsComplete !== "boolean") {
    state.announcementsComplete = false;
  }
  while (state.queue.length > 0 || state.detailQueue.length > 0) {
    await discoverContent(options, state);
    await discoverContentDetails(options, state);
  }
  await discoverAnnouncements(options, state);
  state.complete = true;
  await checkpoint(options, state);
  const status = state.sources.length === 0 && state.issues.length > 0 ? "Failed" : state.issues.length > 0 ? "Partial" : "Complete";
  return { checkpoint: state, status };
}

// src/recovery/lease.ts
var SCAN_LEASES_KEY = "syllab.scanLeases";
var SCAN_LEASE_DURATION_MS = 45e3;
function leasesFrom(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value) ? value : {};
}
var ScanLeaseRepository = class {
  constructor(storage) {
    this.storage = storage;
  }
  async renew(scanId, now = /* @__PURE__ */ new Date()) {
    const current = await this.storage.get(SCAN_LEASES_KEY);
    const leases = leasesFrom(current[SCAN_LEASES_KEY]);
    await this.storage.set({
      [SCAN_LEASES_KEY]: {
        ...leases,
        [scanId]: {
          scanId,
          expiresAt: new Date(now.getTime() + SCAN_LEASE_DURATION_MS).toISOString()
        }
      }
    });
  }
  async clear(scanId) {
    const current = await this.storage.get(SCAN_LEASES_KEY);
    const leases = leasesFrom(current[SCAN_LEASES_KEY]);
    const next = Object.fromEntries(Object.entries(leases).filter(([key]) => key !== scanId));
    await this.storage.set({ [SCAN_LEASES_KEY]: next });
  }
  async interruptExpired(scans, now = /* @__PURE__ */ new Date()) {
    const current = await this.storage.get(SCAN_LEASES_KEY);
    const leases = leasesFrom(current[SCAN_LEASES_KEY]);
    return scans.map((scan) => {
      if (scan.status !== "Scanning") return structuredClone(scan);
      const lease = leases[scan.scanId];
      if (!lease || Date.parse(lease.expiresAt) > now.getTime()) return structuredClone(scan);
      return { ...structuredClone(scan), status: "Interrupted", recoverable: true };
    });
  }
};
async function withScanLease(storage, scanId, work) {
  const repository = new ScanLeaseRepository(storage);
  await repository.renew(scanId);
  const heartbeat = setInterval(() => void repository.renew(scanId), SCAN_LEASE_DURATION_MS / 3);
  try {
    return await work();
  } finally {
    clearInterval(heartbeat);
    await repository.clear(scanId);
  }
}

// src/background/discovery-runner.ts
var ChromeTabDiscoveryApi = class {
  constructor(tabId, courseId) {
    this.tabId = tabId;
    this.courseId = courseId;
  }
  async get(endpoint) {
    const response = await chrome.tabs.sendMessage(this.tabId, {
      contractVersion: CONTRACT_VERSION,
      type: "DISCOVERY_API_GET",
      courseId: this.courseId,
      endpoint
    });
    if (!isRecord(response) || response.ok !== true) {
      throw new DiscoveryApiError(
        isRecord(response) && typeof response.message === "string" ? response.message : "Course API bridge returned an invalid response",
        isRecord(response) && typeof response.status === "number" ? response.status : void 0
      );
    }
    return response.payload;
  }
};
async function startDiscovery(courseId, tabId, restartScanId) {
  const repository = new DiscoveryRepository(chrome.storage.local);
  const recoverable = restartScanId ? null : await repository.findRecoverableDiscovery(courseId);
  const scanId = restartScanId ?? recoverable?.summary.scanId ?? crypto.randomUUID();
  const summary = recoverable?.summary ?? {
    scanId,
    courseId,
    status: "Scanning",
    recoverable: true,
    phase: "discovery"
  };
  await repository.upsertScanSummary(summary);
  const result = await withScanLease(
    chrome.storage.local,
    scanId,
    () => runDiscovery({
      scanId,
      courseId,
      origin: "https://ntulearn.ntu.edu.sg",
      api: new ChromeTabDiscoveryApi(tabId, courseId),
      ...recoverable ? { checkpoint: recoverable.checkpoint } : {},
      onCheckpoint: (value) => repository.saveCheckpoint(value)
    })
  );
  const latest = await repository.getScanSummary(scanId);
  if (latest?.status !== "Interrupted") {
    await repository.upsertScanSummary(
      result.status === "Failed" ? { ...summary, status: "Failed", recoverable: false, phase: "discovery" } : { ...summary, phase: "fetch" }
    );
  }
  return {
    scanId,
    discoveryStatus: result.status,
    sourceCount: result.checkpoint.sources.length,
    issueCount: result.checkpoint.issues.length,
    pagesProcessed: result.checkpoint.pagesProcessed,
    resumed: recoverable !== null
  };
}

// src/fetch/attachment-fetcher.ts
var PROVISIONAL_FETCH_LIMIT_BYTES = 64 * 1024 * 1024;
function hex(bytes) {
  return [...bytes].map((value) => value.toString(16).padStart(2, "0")).join("");
}
function signature(bytes) {
  const firstEight = bytes.slice(0, 8);
  const text = new TextDecoder("ascii").decode(firstEight);
  if (text.startsWith("%PDF-")) return "pdf";
  if (firstEight[0] === 80 && firstEight[1] === 75) return "zip";
  if (hex(firstEight) === "d0cf11e0a1b11ae1") return "ole";
  return `unknown:${hex(firstEight)}`;
}
async function readBounded(response, maxBytes) {
  const declaredLength = Number(response.headers.get("content-length"));
  if (Number.isFinite(declaredLength) && declaredLength > maxBytes) {
    throw new Error("ATTACHMENT_SIZE_LIMIT");
  }
  if (!response.body) return new Uint8Array(await response.arrayBuffer());
  const reader = response.body.getReader();
  const chunks = [];
  let total = 0;
  let streamComplete = false;
  try {
    while (!streamComplete) {
      const { done, value } = await reader.read();
      if (done) {
        streamComplete = true;
        continue;
      }
      total += value.byteLength;
      if (total > maxBytes) {
        await reader.cancel("attachment size limit");
        throw new Error("ATTACHMENT_SIZE_LIMIT");
      }
      chunks.push(value);
    }
  } finally {
    reader.releaseLock();
  }
  const bytes = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.byteLength;
  }
  return bytes;
}
async function fetchAttachment(sourceId, requestUrl, options = {}) {
  return (await fetchAttachmentPayload(sourceId, requestUrl, options)).result;
}
async function fetchAttachmentPayload(sourceId, requestUrl, options = {}) {
  const fetchImpl = options.fetchImpl ?? fetch;
  const maxBytes = options.maxBytes ?? PROVISIONAL_FETCH_LIMIT_BYTES;
  try {
    const response = await fetchImpl(requestUrl, {
      method: "GET",
      credentials: "include",
      redirect: "follow",
      cache: "no-store",
      ...options.signal ? { signal: options.signal } : {}
    });
    if (!response.ok) {
      return {
        result: { sourceId, status: "failed", httpStatus: response.status, errorCode: "HTTP_ERROR" }
      };
    }
    if (response.status === 206 || response.headers.has("content-range")) {
      await response.body?.cancel();
      return {
        result: {
          sourceId,
          status: "failed",
          httpStatus: response.status,
          errorCode: "PARTIAL_CONTENT"
        }
      };
    }
    const bytes = await readBounded(response, maxBytes);
    const digest = await crypto.subtle.digest("SHA-256", bytes.buffer);
    const contentType = response.headers.get("content-type");
    const contentDisposition = response.headers.get("content-disposition");
    return {
      result: {
        sourceId,
        status: "fetched",
        finalOrigin: new URL(response.url || requestUrl).origin,
        httpStatus: response.status,
        ...contentType ? { contentType } : {},
        ...contentDisposition ? { contentDisposition } : {},
        byteLength: bytes.byteLength,
        signature: signature(bytes),
        sha256: hex(new Uint8Array(digest))
      },
      bytes
    };
  } catch (error) {
    return {
      result: {
        sourceId,
        status: "failed",
        errorCode: error instanceof Error && error.message === "ATTACHMENT_SIZE_LIMIT" ? "ATTACHMENT_SIZE_LIMIT" : error instanceof DOMException && error.name === "AbortError" ? "CANCELLED" : "FETCH_FAILED"
      }
    };
  }
}

// src/fetch/permission-planner.ts
function exactOriginPattern(origin) {
  const url = new URL(origin);
  if (url.protocol !== "https:" || url.origin !== origin || url.hostname.includes("*")) {
    throw new Error("Permission origin must be an exact HTTPS origin");
  }
  return `${url.origin}/*`;
}
function createFetchCheckpoint(scanId, sources, approvedOrigin) {
  const byOrigin = /* @__PURE__ */ new Map();
  for (const source of sources) {
    const url = new URL(source.requestUrl);
    if (url.protocol !== "https:" || url.origin === approvedOrigin) continue;
    const sourceIds = byOrigin.get(url.origin) ?? [];
    if (!sourceIds.includes(source.sourceId)) sourceIds.push(source.sourceId);
    byOrigin.set(url.origin, sourceIds);
  }
  const pendingOrigins = [...byOrigin].sort(([left], [right]) => left.localeCompare(right)).map(([origin, sourceIds]) => ({
    origin,
    permissionPattern: exactOriginPattern(origin),
    sourceIds,
    decision: "pending",
    requested: false
  }));
  return { scanId, pendingOrigins, results: [], complete: false };
}
function addPendingOrigin(checkpoint2, origin, sourceId) {
  const permissionPattern = exactOriginPattern(origin);
  const existing = checkpoint2.pendingOrigins.find((entry) => entry.origin === origin);
  if (existing) {
    if (!existing.sourceIds.includes(sourceId)) existing.sourceIds.push(sourceId);
  } else {
    checkpoint2.pendingOrigins.push({
      origin,
      permissionPattern,
      sourceIds: [sourceId],
      decision: "pending",
      requested: false
    });
  }
  return structuredClone(checkpoint2);
}
function recordPermissionDecision(checkpoint2, origin, granted) {
  const target = checkpoint2.pendingOrigins.find((entry) => entry.origin === origin);
  if (!target) throw new Error("Permission origin is not pending for this scan");
  if (target.decision !== "pending") return structuredClone(checkpoint2);
  target.requested = true;
  target.decision = granted ? "granted" : "denied";
  return structuredClone(checkpoint2);
}

// src/fetch/engine.ts
function attachmentSources(sources) {
  return sources.flatMap(
    (source) => source.kind === "attachment" ? [
      {
        sourceId: source.sourceId,
        ...source.requestUrl ? { requestUrl: source.requestUrl } : {}
      }
    ] : []
  );
}
function upsertResult(checkpoint2, result) {
  checkpoint2.results = checkpoint2.results.filter((entry) => entry.sourceId !== result.sourceId);
  checkpoint2.results.push(result);
  return checkpoint2;
}
async function runFetch(options) {
  const attachments = attachmentSources(options.sources);
  let checkpoint2 = structuredClone(
    options.checkpoint ?? createFetchCheckpoint(options.scanId, [], options.approvedOrigin)
  );
  checkpoint2.results = checkpoint2.results.filter(
    (result) => !(result.status === "fetched" && result.signature?.startsWith("unknown:") === true && result.byteLength !== void 0 && result.byteLength < 8)
  );
  for (const pending of checkpoint2.pendingOrigins) {
    if (pending.decision === "pending" && await options.ports.containsPermission(pending.permissionPattern)) {
      checkpoint2 = recordPermissionDecision(checkpoint2, pending.origin, true);
    }
  }
  for (const source of attachments) {
    if (checkpoint2.results.some((result) => result.sourceId === source.sourceId)) continue;
    if (!source.requestUrl) {
      upsertResult(checkpoint2, {
        sourceId: source.sourceId,
        status: "failed",
        errorCode: "MISSING_REQUEST_URL"
      });
      await options.ports.onCheckpoint(structuredClone(checkpoint2));
      continue;
    }
    const denied = checkpoint2.pendingOrigins.some(
      (origin) => origin.decision === "denied" && origin.sourceIds.includes(source.sourceId)
    );
    if (denied) {
      upsertResult(checkpoint2, { sourceId: source.sourceId, status: "permission-denied" });
      await options.ports.onCheckpoint(structuredClone(checkpoint2));
      continue;
    }
    let resolved = false;
    for (let hop = 0; hop < 5 && !resolved; hop += 1) {
      const approvedOrigins = /* @__PURE__ */ new Set([
        options.approvedOrigin,
        ...checkpoint2.pendingOrigins.filter((origin) => origin.decision === "granted").map((origin) => origin.origin)
      ]);
      const redirectOrigin = await options.ports.observeRedirect(
        source.requestUrl,
        approvedOrigins
      );
      if (!redirectOrigin) {
        upsertResult(
          checkpoint2,
          await options.ports.fetchAttachment(source.sourceId, source.requestUrl)
        );
        await options.ports.onCheckpoint(structuredClone(checkpoint2));
        resolved = true;
        continue;
      }
      checkpoint2 = addPendingOrigin(checkpoint2, redirectOrigin, source.sourceId);
      const pending = checkpoint2.pendingOrigins.find((entry) => entry.origin === redirectOrigin);
      if (!pending) throw new Error("Observed permission origin was not checkpointed");
      if (pending.decision === "denied") {
        upsertResult(checkpoint2, { sourceId: source.sourceId, status: "permission-denied" });
        await options.ports.onCheckpoint(structuredClone(checkpoint2));
        resolved = true;
      } else if (pending.decision === "granted" || await options.ports.containsPermission(exactOriginPattern(redirectOrigin))) {
        checkpoint2 = recordPermissionDecision(checkpoint2, redirectOrigin, true);
      } else {
        await options.ports.onCheckpoint(structuredClone(checkpoint2));
        resolved = true;
      }
    }
    if (!resolved) {
      upsertResult(checkpoint2, {
        sourceId: source.sourceId,
        status: "failed",
        errorCode: "REDIRECT_LIMIT"
      });
      await options.ports.onCheckpoint(structuredClone(checkpoint2));
    }
  }
  const waiting = checkpoint2.pendingOrigins.some((origin) => origin.decision === "pending");
  checkpoint2.complete = !waiting && attachments.every((source) => checkpoint2.results.some((r) => r.sourceId === source.sourceId));
  await options.ports.onCheckpoint(structuredClone(checkpoint2));
  return {
    checkpoint: checkpoint2,
    outcome: waiting ? "WaitingForPermission" : checkpoint2.results.some((result) => result.status !== "fetched") ? "Partial" : "Complete"
  };
}

// src/fetch/redirect-observer.ts
async function observeFirstUnapprovedRedirectOrigin(requestUrl, approvedOrigins, eventPort, fetchImpl, signal) {
  const target = new URL(requestUrl);
  if (target.protocol !== "https:" || target.username || target.password) {
    throw new Error("Redirect probe requires a credential-free HTTPS URL");
  }
  let redirectOrigin = null;
  const listener = (details) => {
    if (!details.redirectUrl) return;
    try {
      const source = new URL(details.url);
      const destination = new URL(details.redirectUrl);
      if ((source.origin === target.origin && source.pathname === target.pathname || approvedOrigins.has(source.origin)) && destination.protocol === "https:" && !approvedOrigins.has(destination.origin) && redirectOrigin === null) {
        redirectOrigin = destination.origin;
      }
    } catch {
    }
  };
  const urls = [
    `${target.origin}${target.pathname.replaceAll("*", "%2A")}*`,
    ...[...approvedOrigins].filter((origin) => origin !== target.origin).map((origin) => `${origin}/*`)
  ];
  eventPort.addListener(listener, { urls });
  try {
    const response = await fetchImpl(requestUrl, {
      method: "GET",
      credentials: "include",
      redirect: "follow",
      cache: "no-store",
      ...signal ? { signal } : {}
    });
    await response.body?.cancel();
  } catch {
  } finally {
    eventPort.removeListener(listener);
  }
  return redirectOrigin;
}

// src/repository/fetch-repository.ts
var FETCH_CHECKPOINTS_KEY = "syllab.fetchCheckpoints";
var FetchRepository = class {
  constructor(storage) {
    this.storage = storage;
  }
  async getCheckpoint(scanId) {
    const current = await this.storage.get(FETCH_CHECKPOINTS_KEY);
    const records = current[FETCH_CHECKPOINTS_KEY];
    if (typeof records !== "object" || records === null || Array.isArray(records)) return void 0;
    return records[scanId];
  }
  async saveCheckpoint(checkpoint2) {
    const current = await this.storage.get(FETCH_CHECKPOINTS_KEY);
    const records = typeof current[FETCH_CHECKPOINTS_KEY] === "object" && current[FETCH_CHECKPOINTS_KEY] !== null && !Array.isArray(current[FETCH_CHECKPOINTS_KEY]) ? current[FETCH_CHECKPOINTS_KEY] : {};
    await this.storage.set({
      [FETCH_CHECKPOINTS_KEY]: { ...records, [checkpoint2.scanId]: checkpoint2 }
    });
  }
};

// src/background/fetch-runner.ts
var NTU_LEARN_ORIGIN = "https://ntulearn.ntu.edu.sg";
var redirectEvent = {
  addListener(listener, filter) {
    chrome.webRequest.onBeforeRedirect.addListener(listener, filter);
  },
  removeListener(listener) {
    chrome.webRequest.onBeforeRedirect.removeListener(listener);
  }
};
function publicState(checkpoint2) {
  const pending = checkpoint2?.pendingOrigins.find((origin) => origin.decision === "pending");
  const fetched = checkpoint2?.results.filter((result) => result.status === "fetched") ?? [];
  const signatureCounts = {};
  for (const result of fetched) {
    const signature2 = result.signature ?? "unknown";
    signatureCounts[signature2] = (signatureCounts[signature2] ?? 0) + 1;
  }
  return {
    pendingOrigin: pending ? {
      origin: pending.origin,
      permissionPattern: pending.permissionPattern,
      sourceCount: pending.sourceIds.length
    } : null,
    fetchedCount: fetched.length,
    deniedCount: checkpoint2?.results.filter((result) => result.status === "permission-denied").length ?? 0,
    failedCount: checkpoint2?.results.filter((result) => result.status === "failed").length ?? 0,
    signatureCounts,
    finalOrigins: [
      ...new Set(fetched.flatMap((result) => result.finalOrigin ? [result.finalOrigin] : []))
    ].sort(),
    grantedOrigins: checkpoint2?.pendingOrigins.filter((origin) => origin.decision === "granted").map((origin) => origin.origin).sort() ?? [],
    deniedOrigins: checkpoint2?.pendingOrigins.filter((origin) => origin.decision === "denied").map((origin) => origin.origin).sort() ?? [],
    suspiciousCount: fetched.filter(
      (result) => result.signature?.startsWith("unknown:") === true && result.byteLength !== void 0 && result.byteLength < 8
    ).length,
    complete: checkpoint2?.complete ?? false
  };
}
async function persistScanStatus(discoveryRepository, courseId, scanId, result) {
  const latest = await discoveryRepository.getScanSummary(scanId);
  if (latest?.status === "Interrupted") return;
  const summary = result.outcome === "WaitingForPermission" ? {
    scanId,
    courseId,
    status: "WaitingForPermission",
    recoverable: true,
    phase: "fetch"
  } : {
    scanId,
    courseId,
    status: "Scanning",
    recoverable: true,
    phase: "parse"
  };
  await discoveryRepository.upsertScanSummary(summary);
}
async function startFetch(scanId) {
  const discoveryRepository = new DiscoveryRepository(chrome.storage.local);
  const fetchRepository = new FetchRepository(chrome.storage.local);
  const discovery = await discoveryRepository.getCheckpoint(scanId);
  if (!discovery?.complete) throw new Error("DISCOVERY_NOT_COMPLETE");
  const checkpoint2 = await fetchRepository.getCheckpoint(scanId);
  const result = await runFetch({
    scanId,
    sources: discovery.sources,
    approvedOrigin: NTU_LEARN_ORIGIN,
    ...checkpoint2 ? { checkpoint: checkpoint2 } : {},
    ports: {
      containsPermission: (permissionPattern) => chrome.permissions.contains({ origins: [permissionPattern] }),
      observeRedirect: (requestUrl, approvedOrigins) => observeFirstUnapprovedRedirectOrigin(requestUrl, approvedOrigins, redirectEvent, fetch),
      fetchAttachment: (sourceId, requestUrl) => fetchAttachment(sourceId, requestUrl),
      onCheckpoint: (value) => fetchRepository.saveCheckpoint(value)
    }
  });
  await persistScanStatus(discoveryRepository, discovery.courseId, scanId, result);
  return { outcome: result.outcome, state: publicState(result.checkpoint) };
}
async function getFetchState(scanId) {
  return publicState(await new FetchRepository(chrome.storage.local).getCheckpoint(scanId));
}
async function applyPermissionDecision(scanId, origin, granted) {
  const repository = new FetchRepository(chrome.storage.local);
  const checkpoint2 = await repository.getCheckpoint(scanId);
  if (!checkpoint2) throw new Error("FETCH_CHECKPOINT_NOT_FOUND");
  const pending = checkpoint2.pendingOrigins.find((entry) => entry.origin === origin);
  if (!pending || pending.decision !== "pending") {
    throw new Error("PERMISSION_ORIGIN_NOT_PENDING");
  }
  if (granted) {
    const currentlyGranted = await chrome.permissions.contains({
      origins: [pending.permissionPattern]
    });
    if (!currentlyGranted) throw new Error("PERMISSION_NOT_GRANTED");
  }
  await repository.saveCheckpoint(recordPermissionDecision(checkpoint2, origin, granted));
  return startFetch(scanId);
}

// src/repository/local-database.ts
var CANDIDATES_STORE = "candidates";
var REVIEW_PROGRESS_STORE = "reviewProgress";
var BRIEF_ITEMS_STORE = "briefItems";
var PARSED_SOURCES_STORE = "parsedSources";
var NORMALIZED_UNITS_STORE = "normalizedUnits";
function requestResult(request) {
  return new Promise((resolve, reject) => {
    request.addEventListener("success", () => resolve(request.result), { once: true });
    request.addEventListener(
      "error",
      () => reject(request.error ?? new Error("INDEXED_DB_ERROR")),
      {
        once: true
      }
    );
  });
}
function transactionComplete(transaction) {
  return new Promise((resolve, reject) => {
    transaction.addEventListener("complete", () => resolve(), { once: true });
    transaction.addEventListener(
      "abort",
      () => reject(transaction.error ?? new Error("INDEXED_DB_ABORT")),
      {
        once: true
      }
    );
    transaction.addEventListener(
      "error",
      () => reject(transaction.error ?? new Error("INDEXED_DB_ERROR")),
      {
        once: true
      }
    );
  });
}
async function openLocalDatabase() {
  const request = indexedDB.open("syllab-local", 4);
  request.addEventListener("upgradeneeded", () => {
    const database = request.result;
    if (!database.objectStoreNames.contains(CANDIDATES_STORE)) {
      const candidates = database.createObjectStore(CANDIDATES_STORE, { keyPath: "candidateId" });
      candidates.createIndex("scanId", "scanId", { unique: false });
    }
    if (!database.objectStoreNames.contains(REVIEW_PROGRESS_STORE)) {
      database.createObjectStore(REVIEW_PROGRESS_STORE, { keyPath: "scanId" });
    }
    if (!database.objectStoreNames.contains(BRIEF_ITEMS_STORE)) {
      const briefs = database.createObjectStore(BRIEF_ITEMS_STORE, { keyPath: "briefItemId" });
      briefs.createIndex("courseId", "courseId", { unique: false });
    }
    if (!database.objectStoreNames.contains(PARSED_SOURCES_STORE)) {
      const parsed = database.createObjectStore(PARSED_SOURCES_STORE, { keyPath: "recordId" });
      parsed.createIndex("scanId", "scanId", { unique: false });
    }
    if (!database.objectStoreNames.contains(NORMALIZED_UNITS_STORE)) {
      const normalized = database.createObjectStore(NORMALIZED_UNITS_STORE, { keyPath: "unitId" });
      normalized.createIndex("scanId", "scanId", { unique: false });
    }
  });
  return requestResult(request);
}

// src/parser/repository.ts
var IndexedDbParsedSourceRepository = class {
  async put(record) {
    const database = await openLocalDatabase();
    try {
      const transaction = database.transaction(PARSED_SOURCES_STORE, "readwrite");
      transaction.objectStore(PARSED_SOURCES_STORE).put(structuredClone(record));
      await transactionComplete(transaction);
    } finally {
      database.close();
    }
  }
  async list(scanId) {
    const database = await openLocalDatabase();
    try {
      const transaction = database.transaction(PARSED_SOURCES_STORE, "readonly");
      const records = await requestResult(
        transaction.objectStore(PARSED_SOURCES_STORE).index("scanId").getAll(scanId)
      );
      await transactionComplete(transaction);
      return records;
    } finally {
      database.close();
    }
  }
};

// src/background/parse-runner.ts
var creatingOffscreen = null;
async function ensureOffscreenDocument() {
  const url = chrome.runtime.getURL("offscreen.html");
  const contexts = await chrome.runtime.getContexts({
    contextTypes: [chrome.runtime.ContextType.OFFSCREEN_DOCUMENT],
    documentUrls: [url]
  });
  if (contexts.length > 0) return;
  creatingOffscreen ??= chrome.offscreen.createDocument({
    url: "offscreen.html",
    reasons: [chrome.offscreen.Reason.WORKERS],
    justification: "Parse one fetched course document per isolated worker"
  });
  try {
    await creatingOffscreen;
  } finally {
    creatingOffscreen = null;
  }
}
function summarize(results, expected) {
  return {
    parsed: results.filter((result) => result.status === "parsed").length,
    partial: results.filter((result) => result.status === "partial").length,
    unsupported: results.filter((result) => result.status === "unsupported").length,
    failed: results.filter((result) => result.status === "failed").length,
    complete: results.length === expected
  };
}
async function startParse(scanId) {
  const discoveryRepository = new DiscoveryRepository(chrome.storage.local);
  const fetchRepository = new FetchRepository(chrome.storage.local);
  const parsedRepository = new IndexedDbParsedSourceRepository();
  const [discovery, fetchCheckpoint, existing] = await Promise.all([
    discoveryRepository.getCheckpoint(scanId),
    fetchRepository.getCheckpoint(scanId),
    parsedRepository.list(scanId)
  ]);
  if (!discovery?.complete || !fetchCheckpoint?.complete) throw new Error("FETCH_NOT_COMPLETE");
  const fetchedIds = new Set(
    fetchCheckpoint.results.filter((result) => result.status === "fetched").map((result) => result.sourceId)
  );
  const attachments = discovery.sources.filter(
    (source) => source.kind === "attachment" && source.requestUrl && fetchedIds.has(source.sourceId)
  );
  const completedRecords = existing.filter((record) => record.result.status !== "failed");
  const completedIds = new Set(completedRecords.map((record) => record.sourceId));
  const results = completedRecords.map((record) => record.result);
  if (attachments.some((source) => !completedIds.has(source.sourceId))) {
    await ensureOffscreenDocument();
  }
  for (const source of attachments) {
    if (completedIds.has(source.sourceId) || !source.requestUrl) continue;
    let result;
    try {
      const response = await chrome.runtime.sendMessage({
        contractVersion: CONTRACT_VERSION,
        type: "PARSE_ATTACHMENT",
        sourceId: source.sourceId,
        requestUrl: source.requestUrl
      });
      if (!isRecord(response) || response.ok !== true || !isRecord(response.result)) {
        throw new Error("PARSER_RUNTIME_FAILED");
      }
      result = response.result;
    } catch {
      result = {
        format: "unsupported",
        status: "failed",
        units: [],
        diagnosticsCode: "PARSER_RUNTIME_FAILED"
      };
    }
    await parsedRepository.put({
      recordId: `${scanId}:${source.sourceId}`,
      scanId,
      courseId: discovery.courseId,
      sourceId: source.sourceId,
      sourceType: source.kind,
      title: source.title,
      path: source.discoveryPath,
      result
    });
    results.push(result);
  }
  const state = summarize(results, attachments.length);
  const summary = {
    scanId,
    courseId: discovery.courseId,
    status: "Scanning",
    recoverable: true,
    phase: "normalize"
  };
  if ((await discoveryRepository.getScanSummary(scanId))?.status !== "Interrupted") {
    await discoveryRepository.upsertScanSummary(summary);
  }
  await chrome.offscreen.closeDocument().catch(() => void 0);
  return state;
}
async function getParseState(scanId) {
  const [discovery, records] = await Promise.all([
    new DiscoveryRepository(chrome.storage.local).getCheckpoint(scanId),
    new IndexedDbParsedSourceRepository().list(scanId)
  ]);
  const expected = discovery?.sources.filter((source) => source.kind === "attachment" && source.requestUrl).length ?? 0;
  return summarize(
    records.map((record) => record.result),
    expected
  );
}

// src/normalize/normalizer.ts
function hex2(bytes) {
  return [...bytes].map((value) => value.toString(16).padStart(2, "0")).join("");
}
function normalizeEvidenceText(text) {
  const withoutMarkup = /<\/?[a-z][\s\S]*>/i.test(text) ? text.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, " ").replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, " ").replace(/<br\s*\/?>|<\/p>|<\/div>|<\/li>|<\/tr>/gi, "\n").replace(/<[^>]+>/g, " ").replaceAll("&nbsp;", " ").replaceAll("&amp;", "&").replaceAll("&lt;", "<").replaceAll("&gt;", ">") : text;
  return withoutMarkup.replaceAll("\r\n", "\n").replaceAll("\r", "\n").replaceAll("\xA0", " ").split("\n").map((line) => line.replace(/[\t ]+/g, " ").trim()).join("\n").replace(/\n{3,}/g, "\n\n").trim();
}
async function sha256(value) {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
  return hex2(new Uint8Array(digest));
}
async function normalizeSourceUnits(rawUnits) {
  const firstByHash = /* @__PURE__ */ new Map();
  const output = [];
  for (const raw of rawUnits) {
    const text = normalizeEvidenceText(raw.text);
    const contentHash = await sha256(text);
    const unitId = `${raw.sourceId}:${raw.locator}`;
    const duplicateOfUnitId = firstByHash.get(contentHash);
    if (!duplicateOfUnitId) firstByHash.set(contentHash, unitId);
    output.push({
      ...raw,
      text,
      unitId,
      contentHash,
      ...duplicateOfUnitId ? { duplicateOfUnitId } : {}
    });
  }
  return output;
}
function createNormalizedBatches(units, maxCharacters = 24e3) {
  if (!Number.isSafeInteger(maxCharacters) || maxCharacters < 1) {
    throw new Error("Batch character limit must be a positive safe integer");
  }
  const batches = [];
  let current = null;
  for (const unit of units) {
    if (unit.text.length > maxCharacters)
      throw new Error(`NORMALIZED_UNIT_TOO_LARGE:${unit.unitId}`);
    const mustStart = !current || current.sourceId !== unit.sourceId || current.characterCount + unit.text.length > maxCharacters;
    if (mustStart) {
      current = {
        batchId: `${unit.sourceId}:batch:${String(batches.filter((b) => b.sourceId === unit.sourceId).length + 1)}`,
        sourceId: unit.sourceId,
        units: [],
        characterCount: 0
      };
      batches.push(current);
    }
    const activeBatch = current;
    if (!activeBatch) throw new Error("Normalized batch state is unavailable");
    activeBatch.units.push(unit);
    activeBatch.characterCount += unit.text.length;
  }
  return batches;
}

// src/normalize/repository.ts
var IndexedDbNormalizedUnitRepository = class {
  async replace(scanId, units) {
    const database = await openLocalDatabase();
    try {
      const transaction = database.transaction(NORMALIZED_UNITS_STORE, "readwrite");
      const store = transaction.objectStore(NORMALIZED_UNITS_STORE);
      const existing = await requestResult(store.index("scanId").getAllKeys(scanId));
      for (const key of existing) store.delete(key);
      for (const unit of units) store.put(structuredClone(unit));
      await transactionComplete(transaction);
    } finally {
      database.close();
    }
  }
  async list(scanId) {
    const database = await openLocalDatabase();
    try {
      const transaction = database.transaction(NORMALIZED_UNITS_STORE, "readonly");
      const units = await requestResult(
        transaction.objectStore(NORMALIZED_UNITS_STORE).index("scanId").getAll(scanId)
      );
      await transactionComplete(transaction);
      return units;
    } finally {
      database.close();
    }
  }
};

// src/background/normalize-runner.ts
async function startNormalize(scanId) {
  const discoveryRepository = new DiscoveryRepository(chrome.storage.local);
  const normalizedRepository = new IndexedDbNormalizedUnitRepository();
  const [discovery, parsed] = await Promise.all([
    discoveryRepository.getCheckpoint(scanId),
    new IndexedDbParsedSourceRepository().list(scanId)
  ]);
  if (!discovery?.complete) throw new Error("DISCOVERY_NOT_COMPLETE");
  const raw = [];
  for (const source of discovery.sources) {
    if (source.kind === "attachment" || !source.rawText) continue;
    raw.push({
      courseId: source.courseId,
      scanId,
      sourceId: source.sourceId,
      sourceType: source.kind,
      title: source.title,
      path: source.discoveryPath,
      locator: "item",
      text: source.rawText
    });
  }
  for (const record of parsed) {
    for (const unit of record.result.units) {
      raw.push({
        courseId: record.courseId,
        scanId,
        sourceId: record.sourceId,
        sourceType: record.sourceType,
        title: record.title,
        path: record.path,
        locator: unit.locator,
        text: unit.text
      });
    }
  }
  const units = await normalizeSourceUnits(raw);
  await normalizedRepository.replace(scanId, units);
  const summary = {
    scanId,
    courseId: discovery.courseId,
    status: "Scanning",
    recoverable: true,
    phase: "extract"
  };
  if ((await discoveryRepository.getScanSummary(scanId))?.status !== "Interrupted") {
    await discoveryRepository.upsertScanSummary(summary);
  }
  return {
    unitCount: units.length,
    duplicateCount: units.filter((unit) => unit.duplicateOfUnitId).length,
    sourceCount: new Set(units.map((unit) => unit.sourceId)).size,
    complete: true
  };
}
async function getNormalizeState(scanId) {
  const units = await new IndexedDbNormalizedUnitRepository().list(scanId);
  return {
    unitCount: units.length,
    duplicateCount: units.filter((unit) => unit.duplicateOfUnitId).length,
    sourceCount: new Set(units.map((unit) => unit.sourceId)).size,
    complete: units.length > 0
  };
}

// src/ai/client.ts
function validatedRelationship(candidate, kind, reviewReason) {
  const scope = candidate.scope;
  const parentKey = candidate.appliesToAssessmentKey;
  if (kind === "assessment") {
    if (scope !== void 0 || parentKey !== void 0) throw new Error("AI_RELATIONSHIP_INVALID");
    return {};
  }
  if (scope === "course" && parentKey === void 0) return { scope };
  if (scope === "assessment" && typeof parentKey === "string" && /^assessment:[a-z0-9][a-z0-9-]*$/.test(parentKey)) {
    return { scope, appliesToAssessmentKey: parentKey };
  }
  if (scope === void 0 && parentKey === void 0 && reviewReason) return {};
  throw new Error("AI_RELATIONSHIP_INVALID");
}
function validatedResponse(value, request) {
  if (!isRecord(value) || value.contractVersion !== CONTRACT_VERSION || value.requestId !== request.requestId || value.provider !== MODEL_PROVIDER || value.model !== MODEL_NAME || !Array.isArray(value.candidates) || !isRecord(value.usage) || typeof value.usage.inputTokens !== "number" || typeof value.usage.outputTokens !== "number") {
    throw new Error("AI_RESPONSE_INVALID");
  }
  const sourceIds = new Set(request.units.map((unit) => unit.sourceId));
  const candidates = value.candidates.map((candidate) => {
    if (!isRecord(candidate) || candidate.kind !== "assessment" && candidate.kind !== "important_date" && candidate.kind !== "important_rule" || !isRecord(candidate.proposedValue) || !Array.isArray(candidate.evidenceRefs) || candidate.evidenceRefs.length === 0) {
      throw new Error("AI_RESPONSE_INVALID");
    }
    const evidenceRefs = candidate.evidenceRefs.map((reference) => {
      if (!isRecord(reference) || typeof reference.sourceId !== "string" || typeof reference.locator !== "string" || !sourceIds.has(reference.sourceId)) {
        throw new Error("AI_EVIDENCE_INVALID");
      }
      return { sourceId: reference.sourceId, locator: reference.locator };
    });
    const kind = candidate.kind;
    const reviewReason = typeof candidate.reviewReason === "string" ? candidate.reviewReason : void 0;
    const relationship = validatedRelationship(candidate, kind, reviewReason);
    return {
      kind,
      ...relationship,
      proposedValue: candidate.proposedValue,
      evidenceRefs,
      ...reviewReason ? { reviewReason } : {}
    };
  });
  return {
    contractVersion: CONTRACT_VERSION,
    requestId: request.requestId,
    provider: MODEL_PROVIDER,
    model: MODEL_NAME,
    candidates,
    usage: { inputTokens: value.usage.inputTokens, outputTokens: value.usage.outputTokens }
  };
}
function normalizedLabel(candidate) {
  const label = ["title", "name", "label", "event", "description", "rule"].map((key) => candidate.proposedValue[key]).find((value) => typeof value === "string");
  return (label ?? JSON.stringify(candidate.proposedValue)).toLowerCase().replace(/\bexamination\b/g, "exam").replace(/\bwritten\b/g, "").replace(/[^a-z0-9]+/g, " ").replace(/\s+/g, " ").trim();
}
function normalizedCalendarDate(value) {
  const iso = value.match(/\b(\d{4})-(\d{2})-(\d{2})\b/);
  if (iso) return iso[0];
  const dayMonthYear = value.match(/\b(\d{1,2})\/(\d{1,2})\/(\d{4})\b/);
  if (dayMonthYear) {
    const day = Number(dayMonthYear[1]);
    const month = Number(dayMonthYear[2]);
    const year = Number(dayMonthYear[3]);
    const calendarDate2 = new Date(year, month - 1, day);
    if (calendarDate2.getFullYear() === year && calendarDate2.getMonth() === month - 1 && calendarDate2.getDate() === day) {
      return `${String(year).padStart(4, "0")}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
    }
    return null;
  }
  const naturalDate = value.match(
    /\b\d{1,2}\s+(?:jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:tember)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\s+\d{4}\b/i
  )?.[0];
  const parsed = Date.parse(naturalDate ?? value);
  if (Number.isNaN(parsed)) return null;
  const calendarDate = new Date(parsed);
  return [calendarDate.getFullYear(), calendarDate.getMonth() + 1, calendarDate.getDate()].map((part, index) => String(part).padStart(index === 0 ? 4 : 2, "0")).join("-");
}
function assessmentEntityKey(text) {
  const ca = text.match(/\b(?:ca\s*|continuous assessment\s*)(\d+)\b/i);
  if (ca?.[1]) return `ca${ca[1]}`;
  if (/\bfinal\s+(?:written\s+)?exam(?:ination)?\b/i.test(text)) return "final-exam";
  return null;
}
function dateEventKey(text, fallback) {
  if (/\bfinal\s+(?:written\s+)?exam(?:ination)?\b/i.test(text)) return "final-exam";
  if (/\bca\s*1\b|\bcontinuous assessment\s*1\b/i.test(text)) {
    if (/peer evaluation/i.test(text)) return "ca1-peer-evaluation";
    if (/batch\s*1/i.test(text)) return "ca1-presentation-batch1";
    if (/batch\s*2/i.test(text)) return "ca1-presentation-batch2";
    if (/role\s*play\s+script/i.test(text)) return "ca1-role-play-script";
    if (/power\s*point|slides?/i.test(text)) return "ca1-presentation-slides";
    return "ca1-submission";
  }
  if (/\bca\s*2\b|\bcontinuous assessment\s*2\b|\bmcq\b/i.test(text)) return "ca2-test";
  if (/\bca\s*3\b|\bcontinuous assessment\s*3\b|case study/i.test(text)) {
    return "ca3-case-study";
  }
  if (/project background|procurement scenario|scenario.*form/i.test(text)) return "scenario-form";
  return fallback;
}
function semanticKey(candidate) {
  const label = normalizedLabel(candidate);
  const proposedText = JSON.stringify(candidate.proposedValue);
  if (candidate.kind === "assessment") {
    return `assessment:${assessmentEntityKey(proposedText) ?? label}`;
  }
  const relationshipKey = candidate.scope === "assessment" ? candidate.appliesToAssessmentKey : candidate.scope === "course" ? "course" : candidate.appliesToAssessmentKey ?? "unresolved";
  if (candidate.kind !== "important_date") {
    return `${candidate.kind}:${label}:${relationshipKey ?? "unresolved"}`;
  }
  const dateValue = Object.entries(candidate.proposedValue).find(
    ([key, value]) => /date|when/i.test(key) && typeof value === "string"
  )?.[1];
  const normalizedDate = typeof dateValue === "string" ? normalizedCalendarDate(dateValue) ?? dateValue : "";
  return `${candidate.kind}:${dateEventKey(proposedText, label)}:${normalizedDate}:${relationshipKey ?? "unresolved"}`;
}
function candidateEvidenceText(candidate, request) {
  const referencedSources = new Set(candidate.evidenceRefs.map((reference) => reference.sourceId));
  return request.units.filter((unit) => referencedSources.has(unit.sourceId)).map((unit) => `${unit.title}
${unit.text}`).join("\n");
}
var D015_GRADE_TERMS = /\b(?:marks?|grades?|grading|scores?|points?|percentage points?)\b/i;
var D015_GRADE_CONSEQUENCE = /\b(?:affect|impact|influence|contribut(?:e|es|ing)|count(?:s|ed|ing)?|result(?:s|ed|ing)?|lead(?:s|ing)?|cause[sd]?|loss|lose|deduct(?:ed|ion)?|penalt(?:y|ies)|zero|receives?|received|given|get|must pass|pass(?:ing)?)\b/i;
function hasD015SourceSupportedGradeImpact(text) {
  if (/\b(?:assessment (?:validity|eligibility)|eligib(?:le|ility)|ineligible|not (?:be )?graded|not accepted|invalid submission|cannot sit|not permitted to (?:sit|take)|must pass|pass(?:ing) grade)\b/i.test(
    text
  )) {
    return true;
  }
  if (/\b(?:late|submission)\b[\s\S]{0,40}\bpenalt(?:y|ies)\b|\bpenalt(?:y|ies)\b[\s\S]{0,40}\blate\b/i.test(
    text
  )) {
    return true;
  }
  if (/\b(?:turnitin|ntu\s*learn)\b[\s\S]{0,100}\b(?:submit|submission|assignment|written work|must|required|invalid|not accepted)\b/i.test(
    text
  )) {
    return true;
  }
  if (!D015_GRADE_TERMS.test(text) || !D015_GRADE_CONSEQUENCE.test(text)) return false;
  return /\b(?:marks?|grades?|grading|scores?|points?|percentage points?)\b[\s\S]{0,100}\b(?:affect|impact|influence|contribut(?:e|es|ing)|count(?:s|ed|ing)?|result(?:s|ed|ing)?|lead(?:s|ing)?|cause[sd]?|loss|lose|deduct(?:ed|ion)?|penalt(?:y|ies)|zero|receives?|received|given|get|must pass|pass(?:ing)?)\b/i.test(
    text
  ) || /\b(?:affect|impact|influence|contribut(?:e|es|ing)|count(?:s|ed|ing)?|result(?:s|ed|ing)?|lead(?:s|ing)?|cause[sd]?|loss|lose|deduct(?:ed|ion)?|penalt(?:y|ies)|zero|receives?|received|given|get|must pass|pass(?:ing)?)\b[\s\S]{0,100}\b(?:marks?|grades?|grading|scores?|points?|percentage points?)\b/i.test(
    text
  );
}
function isD015PolicyBoilerplate(text) {
  const materialsPolicy = /\b(?:course materials?|copyright|intellectual property)\b[\s\S]{0,160}\b(?:upload|reproduc|redistribut|republish|transmit|photograph|film|audio|recording|permission|approval|not permitted|prohibited)\b/i.test(
    text
  );
  const recordingPolicy = /\b(?:photograph|film|audio record|recording)\b[\s\S]{0,80}\b(?:not permitted|prohibited|not allowed|may not|must not|without (?:permission|approval))\b/i.test(
    text
  );
  const conductPolicy = /\b(?:privacy|acceptable[- ]use|campus conduct|conduct policy|disciplin(?:ary|e))\b[\s\S]{0,100}\b(?:policy|policies|rules?|guidelines?|comply|follow|required|prohibited)\b/i.test(
    text
  );
  const integrityPolicy = /\b(?:academic integrity|academic honesty|plagiarism|misconduct)\b[\s\S]{0,100}\b(?:policy|policies|guidelines?|link|see|refer)\b/i.test(
    text
  );
  return materialsPolicy || recordingPolicy || conductPolicy || integrityPolicy;
}
function passesD015ImportantRuleBoundary(candidate, request) {
  if (candidate.kind !== "important_rule") return true;
  if (candidate.scope === "assessment") return true;
  const proposedText = JSON.stringify(candidate.proposedValue);
  const evidenceText = candidateEvidenceText(candidate, request);
  const combinedText = `${proposedText}
${evidenceText}`;
  if (hasD015SourceSupportedGradeImpact(evidenceText)) return true;
  if (/\battendance|attend(?:ance|ing)?\b/i.test(combinedText)) return false;
  if (isD015PolicyBoilerplate(combinedText)) return false;
  return true;
}
function isMvpRelevantCandidate(candidate, request) {
  if (!passesD015ImportantRuleBoundary(candidate, request)) return false;
  if (candidate.kind === "assessment") return true;
  const proposedText = JSON.stringify(candidate.proposedValue);
  if (candidate.kind === "important_date") {
    return /\b(?:ca\s*\d+|assessment|assignment|exam(?:ination)?|quiz|mcq|test|case study|presentation|role play|peer evaluation|submit|submission|deadline|due)\b/i.test(
      proposedText
    );
  }
  const evidenceText = `${proposedText}
${candidateEvidenceText(candidate, request)}`;
  return /\b(?:student|assignment|assessment|ca\s*\d+|exam|quiz|presentation|submit|submission|turnitin|ntu\s*learn|deadline|late penalty|attendance|attend|group members?|group size|word limit|citation|misconduct|generative ai|gai|course materials?|lecture recordings?|photograph|film|audio record|documentary evidence|representative per group)\b/i.test(
    evidenceText
  );
}
function routeCandidateRisk(candidate, request) {
  const referencedEvidence = new Set(
    candidate.evidenceRefs.map((reference) => `${reference.sourceId}\0${reference.locator}`)
  );
  const evidenceText = request.units.filter((unit) => referencedEvidence.has(`${unit.sourceId}\0${unit.locator}`)).map((unit) => unit.text).join("\n");
  const weekOnly = /\bweek\s+\d+\b/i.test(evidenceText) && !/\b\d{4}-\d{2}-\d{2}\b|\b\d{1,2}\s+(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\s+\d{4}\b/i.test(
    evidenceText
  );
  const uncertainAssessment = candidate.kind === "assessment" && /\b(?:ungraded|not graded|optional|practice)\b/i.test(evidenceText);
  if (!weekOnly && !uncertainAssessment) return candidate;
  const proposedValue = weekOnly ? Object.fromEntries(
    Object.entries(candidate.proposedValue).filter(
      ([key]) => !/(?:date|due|deadline|start|end)/i.test(key)
    )
  ) : candidate.proposedValue;
  return {
    ...candidate,
    proposedValue,
    reviewReason: candidate.reviewReason ?? (weekOnly ? "A week reference has no reliable calendar-date mapping." : "The source does not clearly establish that this item is graded.")
  };
}
var identityFields = /* @__PURE__ */ new Set(["title", "name", "label", "event", "what", "description"]);
function valuesEqual(left, right) {
  return JSON.stringify(left) === JSON.stringify(right);
}
function mergeProposedValues(preferred, additional) {
  const value = structuredClone(preferred);
  const conflicts = {};
  for (const [key, incoming] of Object.entries(additional)) {
    if (!(key in value)) {
      value[key] = structuredClone(incoming);
      continue;
    }
    const current = value[key];
    if (valuesEqual(current, incoming)) continue;
    if (identityFields.has(key)) continue;
    if (/date|when/i.test(key) && typeof current === "string" && typeof incoming === "string") {
      if (normalizedCalendarDate(current) === normalizedCalendarDate(incoming)) continue;
    }
    conflicts[key] = [structuredClone(current), structuredClone(incoming)];
  }
  return { value, conflicts };
}
function normalizedRelationshipText(value) {
  return value.toLowerCase().replace(/peer assessment/g, "peer evaluation").replace(/[^a-z0-9]+/g, " ").replace(/\s+/g, " ").trim();
}
function stringsFromValue(value) {
  if (typeof value === "string") return [value];
  if (Array.isArray(value)) return value.flatMap((item) => stringsFromValue(item));
  if (!isRecord(value)) return [];
  return Object.values(value).flatMap((item) => stringsFromValue(item));
}
function assessmentIdentities(candidates) {
  return candidates.filter((candidate) => candidate.kind === "assessment").map((candidate) => {
    const key = semanticKey(candidate);
    const aliases = stringsFromValue(candidate.proposedValue).map(normalizedRelationshipText).filter((value) => value.length >= 4 && !/^\d+(?:\s*(?:marks?|%))?$/.test(value));
    return { key, aliases: [...new Set(aliases)] };
  });
}
function explicitParentKey(text) {
  const entity = assessmentEntityKey(text);
  return entity ? `assessment:${entity}` : null;
}
function aliasParentKey(text, identities) {
  const normalized = normalizedRelationshipText(text);
  const tokens = new Set(normalized.split(" ").filter((token) => token.length > 1));
  const matches = /* @__PURE__ */ new Set();
  for (const identity of identities) {
    if (identity.aliases.some((alias) => {
      if (normalized.includes(alias) || alias.includes(normalized)) return true;
      const aliasTokens = new Set(alias.split(" ").filter((token) => token.length > 1));
      return tokens.size >= 3 && [...tokens].every((token) => aliasTokens.has(token));
    })) {
      matches.add(identity.key);
    }
  }
  return matches.size === 1 ? [...matches][0] ?? null : null;
}
function isExplicitCourseRule(text) {
  return /\b(?:all course materials|all written assignments|students are expected|deadline extensions?|absence from class|attendance is mandatory|academic integrity|course-wide|all assignments)\b/i.test(
    text
  );
}
function migrateCandidateRelationship(candidate, identities) {
  const next = structuredClone(candidate);
  if (next.kind === "assessment" || next.scope === "course" && !next.appliesToAssessmentKey) {
    return next;
  }
  if (next.scope === "assessment" && next.appliesToAssessmentKey) {
    if (identities.some((identity) => identity.key === next.appliesToAssessmentKey)) return next;
    if (identities.length === 0) return next;
    const remappedParent = aliasParentKey(
      next.appliesToAssessmentKey.replace(/^assessment:/, "").replace(/-/g, " "),
      identities
    );
    if (remappedParent) {
      next.appliesToAssessmentKey = remappedParent;
      return next;
    }
    delete next.scope;
    next.status = "NeedsReview";
    next.reviewReason ??= "The referenced parent Assessment was not found. Choose the correct Assessment before confirming.";
    return next;
  }
  const text = JSON.stringify(next.proposedValue);
  const parentKey = explicitParentKey(text) ?? aliasParentKey(text, identities);
  if (parentKey) {
    next.scope = "assessment";
    next.appliesToAssessmentKey = parentKey;
    return next;
  }
  if (next.kind === "important_date" || isExplicitCourseRule(text)) {
    next.scope = "course";
    delete next.appliesToAssessmentKey;
    return next;
  }
  delete next.scope;
  delete next.appliesToAssessmentKey;
  next.status = "NeedsReview";
  next.reviewReason ??= "It is unclear whether this requirement is course-wide or belongs to an Assessment.";
  return next;
}
function removeFalseUngradedRisk(candidate) {
  const next = structuredClone(candidate);
  if (next.kind === "assessment" && next.status === "NeedsReview" && next.reviewReason === "The source does not clearly establish that this item is graded." && Object.entries(next.proposedValue).some(
    ([key, value]) => /^(?:weight|marks?|score|grade)$/i.test(key) && (typeof value === "number" && Number.isFinite(value) || typeof value === "string" && /\d/.test(value))
  )) {
    next.status = "Detected";
    delete next.reviewReason;
  }
  return next;
}
function mergeCandidateRecords(candidates) {
  const identities = assessmentIdentities(candidates);
  const merged = /* @__PURE__ */ new Map();
  for (const candidate of candidates) {
    const isUnreviewed = candidate.status === "Detected" || candidate.status === "NeedsReview";
    const next = isUnreviewed ? removeFalseUngradedRisk(migrateCandidateRelationship(candidate, identities)) : structuredClone(candidate);
    if (isUnreviewed) next.semanticKey = semanticKey(next);
    const mapKey = isUnreviewed ? next.semanticKey : `${next.semanticKey}:${next.candidateId}`;
    const existing = merged.get(mapKey);
    if (!existing) {
      merged.set(mapKey, next);
      continue;
    }
    const existingSize = JSON.stringify(existing.proposedValue).length;
    const nextSize = JSON.stringify(next.proposedValue).length;
    const preferred = nextSize > existingSize ? next : existing;
    const additional = preferred === existing ? next : existing;
    const combined = mergeProposedValues(preferred.proposedValue, additional.proposedValue);
    const evidenceRefs = [...existing.evidenceRefs];
    for (const reference of next.evidenceRefs) {
      if (!evidenceRefs.some(
        (current) => current.sourceId === reference.sourceId && current.locator === reference.locator
      )) {
        evidenceRefs.push(reference);
      }
    }
    const result = structuredClone(preferred);
    result.semanticKey = next.semanticKey;
    result.proposedValue = combined.value;
    const unresolvedFields = {
      ...structuredClone(existing.unresolvedFields ?? {}),
      ...structuredClone(next.unresolvedFields ?? {}),
      ...combined.conflicts
    };
    if (Object.keys(unresolvedFields).length > 0) result.unresolvedFields = unresolvedFields;
    result.evidenceRefs = evidenceRefs;
    const reviewReason = existing.reviewReason ?? next.reviewReason;
    if (reviewReason) result.reviewReason = reviewReason;
    if (Object.keys(combined.conflicts).length > 0) {
      result.status = "NeedsReview";
      result.reviewReason ??= "Conflicting values were found for the same course fact.";
    } else if (existing.status === "NeedsReview" || next.status === "NeedsReview") {
      result.status = "NeedsReview";
    }
    merged.set(mapKey, result);
  }
  return [...merged.values()];
}
async function installationCredentials(repository, transport) {
  const current = await repository.get();
  const installationId = current?.installationId ?? crypto.randomUUID();
  if (current?.installationToken) return { installationId, token: current.installationToken };
  const token = await transport.register(installationId);
  await repository.save({ installationId, installationToken: token });
  return { installationId, token };
}
async function extractCandidateBatches(options) {
  if (options.batches.length === 0) return { candidates: [], failures: [] };
  const installation = await installationCredentials(options.credentials, options.transport);
  let token = installation.token;
  let tokenRefreshAttempted = false;
  const now = options.now ?? (() => /* @__PURE__ */ new Date());
  const candidates = [];
  const failures = [];
  for (const batch of options.batches) {
    const request = {
      contractVersion: CONTRACT_VERSION,
      requestId: crypto.randomUUID(),
      courseId: options.courseId,
      units: batch.units.map((unit) => ({
        sourceId: unit.sourceId,
        sourceType: unit.sourceType,
        title: unit.title,
        locator: unit.locator,
        text: unit.text,
        contentHash: unit.contentHash
      }))
    };
    try {
      let payload;
      try {
        payload = await options.transport.extract(token, request);
      } catch (error) {
        if (error instanceof Error && error.message === "UNAUTHORIZED" && !tokenRefreshAttempted) {
          tokenRefreshAttempted = true;
          token = await options.transport.register(installation.installationId);
          await options.credentials.save({
            installationId: installation.installationId,
            installationToken: token
          });
          payload = await options.transport.extract(token, request);
        } else {
          throw error;
        }
      }
      const response = validatedResponse(payload, request);
      for (const extracted of response.candidates) {
        const candidate = routeCandidateRisk(extracted, request);
        if (!isMvpRelevantCandidate(candidate, request)) continue;
        candidates.push({
          ...candidate,
          candidateId: crypto.randomUUID(),
          courseId: options.courseId,
          scanId: options.scanId,
          status: candidate.reviewReason ? "NeedsReview" : "Detected",
          semanticKey: semanticKey(candidate),
          createdAt: now().toISOString(),
          providerResponse: {
            provider: response.provider,
            model: response.model,
            requestId: response.requestId
          }
        });
      }
    } catch (error) {
      failures.push({
        batchId: batch.batchId,
        code: error instanceof Error ? error.message : "AI_BATCH_FAILED"
      });
    }
  }
  const mergedCandidates = mergeCandidateRecords(candidates);
  const byKey = /* @__PURE__ */ new Map();
  for (const candidate of mergedCandidates) {
    const group = byKey.get(candidate.semanticKey) ?? [];
    group.push(candidate);
    byKey.set(candidate.semanticKey, group);
  }
  for (const group of byKey.values()) {
    const values = new Set(group.map((candidate) => JSON.stringify(candidate.proposedValue)));
    if (values.size <= 1) continue;
    const conflictGroupId = crypto.randomUUID();
    for (const candidate of group) {
      candidate.status = "NeedsReview";
      candidate.conflictGroupId = conflictGroupId;
      candidate.reviewReason ??= "Conflicting values were found for the same course fact.";
    }
  }
  return { candidates: mergedCandidates, failures };
}

// src/ai/http-transport.ts
var BACKEND_BASE_URL = true ? "http://127.0.0.1:8787" : "http://127.0.0.1:8787";
var ChromeInstallationCredentialRepository = class {
  key = "syllab.installationCredentials";
  async get() {
    const result = await chrome.storage.local.get(this.key);
    const value = result[this.key];
    if (!isRecord(value) || typeof value.installationId !== "string") return null;
    return {
      installationId: value.installationId,
      ...typeof value.installationToken === "string" ? { installationToken: value.installationToken } : {}
    };
  }
  async save(credentials) {
    await chrome.storage.local.set({ [this.key]: credentials });
  }
};
var HttpAiBackendTransport = class {
  constructor(baseUrl = BACKEND_BASE_URL, fetchImpl = globalThis.fetch) {
    this.baseUrl = baseUrl;
    this.fetchImpl = fetchImpl;
  }
  async register(installationId) {
    const response = await this.fetchImpl.call(
      globalThis,
      `${this.baseUrl}/installation/register`,
      {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          contractVersion: CONTRACT_VERSION,
          installationId,
          clientVersion: chrome.runtime.getManifest().version
        })
      }
    );
    const payload = await response.json();
    if (!response.ok || !isRecord(payload) || typeof payload.installationToken !== "string") {
      throw new Error("INSTALLATION_REGISTRATION_FAILED");
    }
    return payload.installationToken;
  }
  async extract(token, request) {
    const response = await this.fetchImpl.call(globalThis, `${this.baseUrl}/ai/extract`, {
      method: "POST",
      headers: {
        authorization: `Bearer ${token}`,
        "content-type": "application/json"
      },
      body: JSON.stringify(request)
    });
    const payload = await response.json();
    if (!response.ok) {
      const code = isRecord(payload) && isRecord(payload.error) ? payload.error.code : void 0;
      throw new Error(typeof code === "string" ? code : "AI_BACKEND_FAILED");
    }
    return payload;
  }
};

// src/review/state.ts
function reviewProgress(scanId, candidates) {
  const detected = candidates.filter((candidate) => candidate.status === "Detected").length;
  const needsReview = candidates.filter((candidate) => candidate.status === "NeedsReview").length;
  return {
    scanId,
    total: candidates.length,
    reviewed: candidates.length - detected - needsReview,
    detected,
    needsReview,
    complete: detected === 0 && needsReview === 0
  };
}

// src/review/repository.ts
var IndexedDbReviewRepository = class {
  async save(scanId, candidates, progress) {
    const database = await openLocalDatabase();
    try {
      const transaction = database.transaction(
        [CANDIDATES_STORE, REVIEW_PROGRESS_STORE],
        "readwrite"
      );
      const candidateStore = transaction.objectStore(CANDIDATES_STORE);
      const existing = await requestResult(candidateStore.index("scanId").getAllKeys(scanId));
      for (const key of existing) candidateStore.delete(key);
      for (const candidate of candidates) candidateStore.put(structuredClone(candidate));
      transaction.objectStore(REVIEW_PROGRESS_STORE).put(structuredClone(progress));
      await transactionComplete(transaction);
    } finally {
      database.close();
    }
  }
  async load(scanId) {
    const database = await openLocalDatabase();
    try {
      const transaction = database.transaction(
        [CANDIDATES_STORE, REVIEW_PROGRESS_STORE],
        "readonly"
      );
      const [candidates, progress] = await Promise.all([
        requestResult(
          transaction.objectStore(CANDIDATES_STORE).index("scanId").getAll(scanId)
        ),
        requestResult(transaction.objectStore(REVIEW_PROGRESS_STORE).get(scanId))
      ]);
      await transactionComplete(transaction);
      return { candidates, progress: progress ?? null };
    } finally {
      database.close();
    }
  }
};

// src/brief/repository.ts
var IndexedDbBriefRepository = class {
  async listAllItems() {
    const database = await openLocalDatabase();
    try {
      const transaction = database.transaction(BRIEF_ITEMS_STORE, "readonly");
      const items = await requestResult(
        transaction.objectStore(BRIEF_ITEMS_STORE).getAll()
      );
      await transactionComplete(transaction);
      return items;
    } finally {
      database.close();
    }
  }
  async upsertCourseItems(items) {
    if (items.length === 0) return;
    const database = await openLocalDatabase();
    try {
      const transaction = database.transaction(BRIEF_ITEMS_STORE, "readwrite");
      const store = transaction.objectStore(BRIEF_ITEMS_STORE);
      for (const item of items) store.put(structuredClone(item));
      await transactionComplete(transaction);
    } finally {
      database.close();
    }
  }
  async replaceCourseItems(courseId, items) {
    const database = await openLocalDatabase();
    try {
      const transaction = database.transaction(BRIEF_ITEMS_STORE, "readwrite");
      const store = transaction.objectStore(BRIEF_ITEMS_STORE);
      const existing = await requestResult(store.index("courseId").getAllKeys(courseId));
      for (const key of existing) store.delete(key);
      for (const item of items) store.put(structuredClone(item));
      await transactionComplete(transaction);
    } finally {
      database.close();
    }
  }
  async listCourseItems(courseId) {
    const database = await openLocalDatabase();
    try {
      const transaction = database.transaction(BRIEF_ITEMS_STORE, "readonly");
      const items = await requestResult(
        transaction.objectStore(BRIEF_ITEMS_STORE).index("courseId").getAll(courseId)
      );
      await transactionComplete(transaction);
      return items;
    } finally {
      database.close();
    }
  }
};

// src/scan-again/reconcile.ts
function inferredSemanticKey(item, prior) {
  return item.semanticKey ?? prior.find((candidate) => item.sourceCandidateRefs.includes(candidate.candidateId))?.semanticKey;
}
function inferredParentKey(item, items, prior) {
  if (item.parentSemanticKey) return item.parentSemanticKey;
  const parent = item.parentBriefItemId ? items.find((candidate) => candidate.briefItemId === item.parentBriefItemId) : void 0;
  return parent ? inferredSemanticKey(parent, prior) : void 0;
}
function sameValue(left, right) {
  return JSON.stringify(left) === JSON.stringify(right);
}
function reconcileScanAgain(candidates, briefItems, priorCandidates) {
  const brief = briefItems.map((item) => structuredClone(item));
  const remaining = [];
  let linkedCount = 0;
  for (const candidate of candidates) {
    const match = brief.find(
      (item) => item.origin === "candidate" && item.status === "Confirmed" && item.kind === candidate.kind && inferredSemanticKey(item, priorCandidates) === candidate.semanticKey && sameValue(item.currentValue, candidate.proposedValue) && (item.scope ?? void 0) === (candidate.scope ?? void 0) && inferredParentKey(item, brief, priorCandidates) === (candidate.appliesToAssessmentKey ?? void 0)
    );
    if (!match) {
      remaining.push(structuredClone(candidate));
      continue;
    }
    linkedCount += 1;
    if (!match.sourceCandidateRefs.includes(candidate.candidateId)) {
      match.sourceCandidateRefs.push(candidate.candidateId);
    }
    for (const evidence of candidate.evidenceRefs) {
      if (!match.evidenceRefs.some(
        (existing) => existing.sourceId === evidence.sourceId && existing.locator === evidence.locator
      )) {
        match.evidenceRefs.push(structuredClone(evidence));
      }
    }
  }
  return { candidates: remaining, briefItems: brief, linkedCount };
}

// src/background/extraction-runner.ts
async function startExtraction(scanId) {
  const discoveryRepository = new DiscoveryRepository(chrome.storage.local);
  const reviewRepository = new IndexedDbReviewRepository();
  const courseRepository = new CourseIndexRepository(chrome.storage.local);
  const briefRepository = new IndexedDbBriefRepository();
  const [discovery, units, existingReview, existingCourse, existingBrief, fetchState, parsed] = await Promise.all([
    discoveryRepository.getCheckpoint(scanId),
    new IndexedDbNormalizedUnitRepository().list(scanId),
    reviewRepository.load(scanId),
    courseRepository.findCourseByScanFallback(scanId),
    briefRepository.listAllItems(),
    new FetchRepository(chrome.storage.local).getCheckpoint(scanId),
    new IndexedDbParsedSourceRepository().list(scanId)
  ]);
  if (!discovery?.complete) throw new Error("DISCOVERY_NOT_COMPLETE");
  if (existingReview.progress && existingReview.progress.reviewed > 0) {
    throw new Error("REVIEW_ALREADY_STARTED");
  }
  const batches = createNormalizedBatches(units);
  const extraction = await extractCandidateBatches({
    courseId: discovery.courseId,
    scanId,
    batches,
    credentials: new ChromeInstallationCredentialRepository(),
    transport: new HttpAiBackendTransport()
  });
  if ((await discoveryRepository.getScanSummary(scanId))?.status === "Interrupted") {
    throw new Error("SCAN_INTERRUPTED");
  }
  let candidates = extraction.candidates;
  if (existingCourse?.lastEffectiveScanId && existingCourse.lastEffectiveScanId !== scanId) {
    const prior = await reviewRepository.load(existingCourse.lastEffectiveScanId);
    const currentBrief = existingBrief.filter((item) => item.courseId === discovery.courseId);
    const reconciled = reconcileScanAgain(candidates, currentBrief, prior.candidates);
    candidates = reconciled.candidates;
    if (reconciled.linkedCount > 0) await briefRepository.upsertCourseItems(reconciled.briefItems);
  }
  const progress = reviewProgress(scanId, candidates);
  await reviewRepository.save(scanId, candidates, progress);
  const upstreamIssueCount = discovery.issues.length + (fetchState?.results.filter(
    (result) => result.status === "permission-denied" || result.status === "failed"
  ).length ?? 0) + parsed.filter(
    (record) => record.result.status === "unsupported" || record.result.status === "failed"
  ).length;
  const outcome = extraction.failures.length === batches.length && candidates.length === 0 || units.length === 0 && upstreamIssueCount > 0 ? "Failed" : extraction.failures.length > 0 || upstreamIssueCount > 0 ? "Partial" : "Complete";
  const scanSummary = {
    scanId,
    courseId: discovery.courseId,
    status: outcome,
    recoverable: outcome === "Failed",
    phase: "extract"
  };
  await discoveryRepository.upsertScanSummary(scanSummary);
  const existing = await courseRepository.findCourse(discovery.courseId);
  await courseRepository.upsertCourse({
    courseId: discovery.courseId,
    ...existing?.courseCode ? { courseCode: existing.courseCode } : {},
    ...existing?.courseName ? { courseName: existing.courseName } : {},
    hasEffectiveScan: outcome === "Failed" ? existing?.hasEffectiveScan ?? false : true,
    hasBrief: (existing?.hasBrief ?? false) || outcome !== "Failed" && progress.complete,
    pendingReviewCount: progress.detected + progress.needsReview,
    ...outcome === "Failed" ? existing?.lastEffectiveScanId ? { lastEffectiveScanId: existing.lastEffectiveScanId } : {} : { lastEffectiveScanId: scanId }
  });
  return {
    candidateCount: candidates.length,
    needsReviewCount: progress.needsReview,
    detectedCount: progress.detected,
    failedBatchCount: extraction.failures.length,
    failureCodes: [...new Set(extraction.failures.map((failure) => failure.code))],
    outcome
  };
}

// src/recovery/overview.ts
function scanIssues(options) {
  const issues = options.discoveryIssues.map((issue) => ({
    ...issue.sourceId ? { sourceId: issue.sourceId } : {},
    reason: "Could Not Access",
    retryable: issue.retryable,
    detail: issue.detail
  }));
  for (const result of options.fetch?.results ?? []) {
    if (result.status === "permission-denied") {
      issues.push({
        sourceId: result.sourceId,
        reason: "Permission Denied",
        retryable: true,
        detail: "The exact attachment host permission was declined."
      });
    } else if (result.status === "failed") {
      issues.push({
        sourceId: result.sourceId,
        reason: "Could Not Access",
        retryable: true,
        detail: result.errorCode ?? "The source could not be fetched."
      });
    }
  }
  for (const record of options.parsed) {
    if (record.result.status === "unsupported") {
      issues.push({
        sourceId: record.sourceId,
        reason: "Unsupported",
        retryable: false,
        detail: record.result.diagnosticsCode ?? "This file format is not supported in the MVP."
      });
    } else if (record.result.status === "failed") {
      issues.push({
        sourceId: record.sourceId,
        reason: "Parsing Failed",
        retryable: true,
        detail: record.result.diagnosticsCode ?? "The supported file could not be parsed."
      });
    }
  }
  if (options.interrupted) {
    issues.push({
      reason: "Interrupted Processing",
      retryable: true,
      detail: "Processing stopped before this scan reached a normal result."
    });
  }
  return issues;
}

// src/background/index.ts
async function initialize() {
  await ensureStorageSchema(chrome.storage.local);
  const courses = new CourseIndexRepository(chrome.storage.local);
  const scans = await courses.listScans();
  const recovered = await new ScanLeaseRepository(chrome.storage.local).interruptExpired(scans);
  if (JSON.stringify(recovered) !== JSON.stringify(scans)) await courses.replaceScans(recovered);
}
chrome.runtime.onInstalled.addListener(() => {
  void initialize();
});
chrome.runtime.onStartup.addListener(() => {
  void initialize();
});
chrome.runtime.onMessage.addListener(
  (message, _sender, sendResponse) => {
    if (!isRecord(message) || message.contractVersion !== CONTRACT_VERSION || message.type !== "GET_SCHEMA_VERSION" && message.type !== "GET_DISCOVERY_SUMMARY" && message.type !== "START_DISCOVERY" && message.type !== "START_FETCH" && message.type !== "GET_FETCH_STATE" && message.type !== "APPLY_PERMISSION_DECISION" && message.type !== "START_PARSE" && message.type !== "GET_PARSE_STATE" && message.type !== "START_NORMALIZE" && message.type !== "GET_NORMALIZE_STATE" && message.type !== "START_EXTRACTION" && message.type !== "RESUME_SCAN" && message.type !== "CANCEL_SCAN" && message.type !== "GET_SCAN_OVERVIEW") {
      return false;
    }
    if (message.type === "GET_SCHEMA_VERSION") {
      void readStorageSchemaVersion(chrome.storage.local).then(
        (schemaVersion) => sendResponse({ contractVersion: CONTRACT_VERSION, schemaVersion }),
        () => sendResponse({ contractVersion: CONTRACT_VERSION, error: "STORAGE_UNAVAILABLE" })
      );
      return true;
    }
    if (message.type === "GET_DISCOVERY_SUMMARY") {
      if (typeof message.scanId !== "string") return false;
      const repository = new DiscoveryRepository(chrome.storage.local);
      void repository.getCheckpoint(message.scanId).then(
        (checkpoint2) => sendResponse({
          contractVersion: CONTRACT_VERSION,
          ...checkpoint2 ? { summary: summarizeDiscovery(checkpoint2) } : { error: "DISCOVERY_CHECKPOINT_NOT_FOUND" }
        }),
        () => sendResponse({ contractVersion: CONTRACT_VERSION, error: "STORAGE_UNAVAILABLE" })
      );
      return true;
    }
    if (message.type === "GET_FETCH_STATE") {
      if (typeof message.scanId !== "string") return false;
      void getFetchState(message.scanId).then(
        (state) => sendResponse({ contractVersion: CONTRACT_VERSION, state }),
        () => sendResponse({ contractVersion: CONTRACT_VERSION, error: "STORAGE_UNAVAILABLE" })
      );
      return true;
    }
    if (message.type === "START_FETCH") {
      if (typeof message.scanId !== "string") return false;
      const scanId = message.scanId;
      void withScanLease(chrome.storage.local, scanId, () => startFetch(scanId)).then(
        (result) => sendResponse({ contractVersion: CONTRACT_VERSION, ...result }),
        (error) => sendResponse({
          contractVersion: CONTRACT_VERSION,
          error: error instanceof Error ? error.message : "Fetch failed"
        })
      );
      return true;
    }
    if (message.type === "APPLY_PERMISSION_DECISION") {
      if (typeof message.scanId !== "string" || typeof message.origin !== "string" || typeof message.granted !== "boolean") {
        return false;
      }
      const scanId = message.scanId;
      const origin = message.origin;
      const granted = message.granted;
      void withScanLease(
        chrome.storage.local,
        scanId,
        () => applyPermissionDecision(scanId, origin, granted)
      ).then(
        (result) => sendResponse({ contractVersion: CONTRACT_VERSION, ...result }),
        (error) => sendResponse({
          contractVersion: CONTRACT_VERSION,
          error: error instanceof Error ? error.message : "Permission decision failed"
        })
      );
      return true;
    }
    if (message.type === "GET_PARSE_STATE") {
      if (typeof message.scanId !== "string") return false;
      void getParseState(message.scanId).then(
        (state) => sendResponse({ contractVersion: CONTRACT_VERSION, state }),
        () => sendResponse({ contractVersion: CONTRACT_VERSION, error: "STORAGE_UNAVAILABLE" })
      );
      return true;
    }
    if (message.type === "START_PARSE") {
      if (typeof message.scanId !== "string") return false;
      const scanId = message.scanId;
      void withScanLease(chrome.storage.local, scanId, () => startParse(scanId)).then(
        (state) => sendResponse({ contractVersion: CONTRACT_VERSION, state }),
        (error) => sendResponse({
          contractVersion: CONTRACT_VERSION,
          error: error instanceof Error ? error.message : "Parse failed"
        })
      );
      return true;
    }
    if (message.type === "GET_NORMALIZE_STATE") {
      if (typeof message.scanId !== "string") return false;
      void getNormalizeState(message.scanId).then(
        (state) => sendResponse({ contractVersion: CONTRACT_VERSION, state }),
        () => sendResponse({ contractVersion: CONTRACT_VERSION, error: "STORAGE_UNAVAILABLE" })
      );
      return true;
    }
    if (message.type === "START_NORMALIZE") {
      if (typeof message.scanId !== "string") return false;
      const scanId = message.scanId;
      void withScanLease(chrome.storage.local, scanId, () => startNormalize(scanId)).then(
        (state) => sendResponse({ contractVersion: CONTRACT_VERSION, state }),
        (error) => sendResponse({
          contractVersion: CONTRACT_VERSION,
          error: error instanceof Error ? error.message : "Normalize failed"
        })
      );
      return true;
    }
    if (message.type === "START_EXTRACTION") {
      if (typeof message.scanId !== "string") return false;
      const scanId = message.scanId;
      void withScanLease(chrome.storage.local, scanId, () => startExtraction(scanId)).then(
        (state) => sendResponse({ contractVersion: CONTRACT_VERSION, state }),
        (error) => sendResponse({
          contractVersion: CONTRACT_VERSION,
          error: error instanceof Error ? error.message : "Extraction failed"
        })
      );
      return true;
    }
    if (message.type === "RESUME_SCAN") {
      if (typeof message.scanId !== "string") return false;
      void new CourseIndexRepository(chrome.storage.local).resumeScan(message.scanId).then(
        (scan) => sendResponse(
          scan ? { contractVersion: CONTRACT_VERSION, status: scan.status } : { contractVersion: CONTRACT_VERSION, error: "SCAN_NOT_RECOVERABLE" }
        ),
        () => sendResponse({ contractVersion: CONTRACT_VERSION, error: "STORAGE_UNAVAILABLE" })
      );
      return true;
    }
    if (message.type === "CANCEL_SCAN") {
      if (typeof message.scanId !== "string") return false;
      const scanId = message.scanId;
      const courses = new CourseIndexRepository(chrome.storage.local);
      void courses.listScans().then(async (scans) => {
        const target = scans.find((scan) => scan.scanId === scanId);
        if (!target) {
          sendResponse({ contractVersion: CONTRACT_VERSION, error: "SCAN_NOT_FOUND" });
          return;
        }
        await courses.replaceScans(
          scans.map(
            (scan) => scan.scanId === scanId ? { ...scan, status: "Interrupted", recoverable: true } : scan
          )
        );
        await new ScanLeaseRepository(chrome.storage.local).clear(scanId);
        sendResponse({ contractVersion: CONTRACT_VERSION, status: "Interrupted" });
      });
      return true;
    }
    if (message.type === "GET_SCAN_OVERVIEW") {
      if (typeof message.scanId !== "string") return false;
      const discoveryRepository = new DiscoveryRepository(chrome.storage.local);
      const courseRepository = new CourseIndexRepository(chrome.storage.local);
      void Promise.all([
        discoveryRepository.getCheckpoint(message.scanId),
        new FetchRepository(chrome.storage.local).getCheckpoint(message.scanId),
        new IndexedDbParsedSourceRepository().list(message.scanId),
        courseRepository.listScans()
      ]).then(([discovery, fetch2, parsed, scans]) => {
        const summary = scans.find((scan) => scan.scanId === message.scanId);
        sendResponse({
          contractVersion: CONTRACT_VERSION,
          issues: scanIssues({
            discoveryIssues: discovery?.issues ?? [],
            ...fetch2 ? { fetch: fetch2 } : {},
            parsed,
            interrupted: summary?.status === "Interrupted"
          })
        });
      });
      return true;
    }
    if (typeof message.courseId !== "string" || typeof message.tabId !== "number") return false;
    void startDiscovery(
      message.courseId,
      message.tabId,
      typeof message.restartScanId === "string" ? message.restartScanId : void 0
    ).then(
      (result) => sendResponse({ contractVersion: CONTRACT_VERSION, ...result }),
      (error) => sendResponse({
        contractVersion: CONTRACT_VERSION,
        error: error instanceof Error ? error.message : "Discovery failed"
      })
    );
    return true;
  }
);
void initialize();
//# sourceMappingURL=background.js.map
