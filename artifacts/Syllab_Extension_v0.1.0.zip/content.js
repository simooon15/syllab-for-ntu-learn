"use strict";
(() => {
  // ../packages/contracts/dist/index.js
  var CONTRACT_VERSION = 1;
  function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }

  // src/content/index.ts
  function detectCourseContext(url) {
    const match = url.pathname.match(/\/ultra\/courses\/([^/]+)\/outline(?:\/|$)/);
    const courseId = match?.[1];
    if (!courseId) return null;
    const courseName = readFirstVisibleText([
      '[data-testid="course-title"]',
      '[data-automation-id="course-title"]',
      "header h1",
      "main h1",
      "h1"
    ]);
    const courseCode = readFirstVisibleText(['[data-testid="course-code"]', '[data-automation-id="course-code"]']) ?? extractDisplayCourseCode(courseName);
    return {
      courseId: decodeURIComponent(courseId),
      route: url.pathname,
      ...courseCode ? { courseCode } : {},
      ...courseName ? { courseName } : {}
    };
  }
  function extractDisplayCourseCode(courseName) {
    return courseName?.match(/\b[A-Z]{2,4}\d{4}[A-Z]?\b/)?.[0];
  }
  function readFirstVisibleText(selectors) {
    if (typeof document === "undefined") return void 0;
    for (const selector of selectors) {
      const element = document.querySelector(selector);
      const text = element?.innerText.trim();
      if (text) return text;
    }
    return void 0;
  }
  if (typeof chrome !== "undefined") {
    chrome.runtime.onMessage.addListener(
      (message, _sender, sendResponse) => {
        if (!isRecord(message) || message.contractVersion !== CONTRACT_VERSION) {
          return false;
        }
        if (message.type === "GET_COURSE_CONTEXT") {
          sendResponse({
            contractVersion: CONTRACT_VERSION,
            context: detectCourseContext(new URL(location.href))
          });
          return false;
        }
        if (message.type === "DISCOVERY_API_GET" && typeof message.courseId === "string" && typeof message.endpoint === "string") {
          void readDiscoveryApi(message.courseId, message.endpoint).then(
            (payload) => sendResponse({ ok: true, payload }),
            (error) => sendResponse({
              ok: false,
              status: isRecord(error) && typeof error.status === "number" ? error.status : void 0,
              message: error instanceof Error ? error.message : "Discovery request failed"
            })
          );
          return true;
        }
        return false;
      }
    );
  }
  function validateDiscoveryEndpoint(courseId, endpoint, approvedOrigin = location.origin) {
    const url = new URL(endpoint, approvedOrigin);
    const prefix = `/learn/api/v1/courses/${encodeURIComponent(courseId)}`;
    const contentPattern = new RegExp(
      `^${prefix.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}/contents/[^/]+(?:/children)?$`
    );
    const isAnnouncement = url.pathname === `${prefix}/announcements`;
    if (url.origin !== approvedOrigin || !contentPattern.test(url.pathname) && !isAnnouncement) {
      throw new Error("Discovery endpoint is outside the approved read-only course API scope");
    }
    return url;
  }
  async function readDiscoveryApi(courseId, endpoint) {
    const url = validateDiscoveryEndpoint(courseId, endpoint);
    const response = await fetch(url, {
      credentials: "include",
      redirect: "error",
      headers: { Accept: "application/json" }
    });
    if (!response.ok) {
      throw Object.assign(new Error(`Course API returned HTTP ${String(response.status)}`), {
        status: response.status
      });
    }
    const contentType = response.headers.get("content-type") ?? "";
    if (!contentType.toLowerCase().includes("application/json")) {
      throw new Error("Course API did not return JSON");
    }
    const text = await response.text();
    if (text.length > 5e6) throw new Error("Course API response exceeded the discovery limit");
    return JSON.parse(text);
  }
})();
//# sourceMappingURL=content.js.map
