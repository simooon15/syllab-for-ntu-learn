// ../packages/contracts/dist/index.js
var CONTRACT_VERSION = 1;
function isRecord(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

// src/fetch/attachment-fetcher.ts
var PROVISIONAL_FETCH_LIMIT_BYTES = 64 * 1024 * 1024;
function hex(bytes) {
  return [...bytes].map((value) => value.toString(16).padStart(2, "0")).join("");
}
function signature(bytes) {
  const firstEight = bytes.slice(0, 8);
  const text = new TextDecoder("ascii").decode(firstEight);
  if (text.startsWith("%PDF-")) return "pdf";
  if (firstEight[0] === 80 && firstEight[1] === 75) return "zip";
  if (hex(firstEight) === "d0cf11e0a1b11ae1") return "ole";
  return `unknown:${hex(firstEight)}`;
}
async function readBounded(response, maxBytes) {
  const declaredLength = Number(response.headers.get("content-length"));
  if (Number.isFinite(declaredLength) && declaredLength > maxBytes) {
    throw new Error("ATTACHMENT_SIZE_LIMIT");
  }
  if (!response.body) return new Uint8Array(await response.arrayBuffer());
  const reader = response.body.getReader();
  const chunks = [];
  let total = 0;
  let streamComplete = false;
  try {
    while (!streamComplete) {
      const { done, value } = await reader.read();
      if (done) {
        streamComplete = true;
        continue;
      }
      total += value.byteLength;
      if (total > maxBytes) {
        await reader.cancel("attachment size limit");
        throw new Error("ATTACHMENT_SIZE_LIMIT");
      }
      chunks.push(value);
    }
  } finally {
    reader.releaseLock();
  }
  const bytes = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.byteLength;
  }
  return bytes;
}
async function fetchAttachmentPayload(sourceId, requestUrl, options = {}) {
  const fetchImpl = options.fetchImpl ?? fetch;
  const maxBytes = options.maxBytes ?? PROVISIONAL_FETCH_LIMIT_BYTES;
  try {
    const response = await fetchImpl(requestUrl, {
      method: "GET",
      credentials: "include",
      redirect: "follow",
      cache: "no-store",
      ...options.signal ? { signal: options.signal } : {}
    });
    if (!response.ok) {
      return {
        result: { sourceId, status: "failed", httpStatus: response.status, errorCode: "HTTP_ERROR" }
      };
    }
    if (response.status === 206 || response.headers.has("content-range")) {
      await response.body?.cancel();
      return {
        result: {
          sourceId,
          status: "failed",
          httpStatus: response.status,
          errorCode: "PARTIAL_CONTENT"
        }
      };
    }
    const bytes = await readBounded(response, maxBytes);
    const digest = await crypto.subtle.digest("SHA-256", bytes.buffer);
    const contentType = response.headers.get("content-type");
    const contentDisposition = response.headers.get("content-disposition");
    return {
      result: {
        sourceId,
        status: "fetched",
        finalOrigin: new URL(response.url || requestUrl).origin,
        httpStatus: response.status,
        ...contentType ? { contentType } : {},
        ...contentDisposition ? { contentDisposition } : {},
        byteLength: bytes.byteLength,
        signature: signature(bytes),
        sha256: hex(new Uint8Array(digest))
      },
      bytes
    };
  } catch (error) {
    return {
      result: {
        sourceId,
        status: "failed",
        errorCode: error instanceof Error && error.message === "ATTACHMENT_SIZE_LIMIT" ? "ATTACHMENT_SIZE_LIMIT" : error instanceof DOMException && error.name === "AbortError" ? "CANCELLED" : "FETCH_FAILED"
      }
    };
  }
}

// src/parser/runtime.ts
function isParseResult(value) {
  if (!isRecord(value) || !Array.isArray(value.units)) return false;
  return typeof value.format === "string" && (value.status === "parsed" || value.status === "partial" || value.status === "unsupported" || value.status === "failed");
}
async function parseInIsolatedWorker(bytes, createWorker, options = {}) {
  const worker = createWorker();
  const requestId = crypto.randomUUID();
  const timeoutMs = options.timeoutMs ?? 3e4;
  const transferable = bytes.slice().buffer;
  return new Promise((resolve, reject) => {
    let settled = false;
    const finish = (callback) => {
      if (settled) return;
      settled = true;
      clearTimeout(timeout);
      options.signal?.removeEventListener("abort", onAbort);
      worker.removeEventListener("message", onMessage);
      worker.terminate();
      callback();
    };
    const onMessage = (event) => {
      const data = event.data;
      if (!isRecord(data) || data.requestId !== requestId) return;
      if (data.status === "COMPLETE" && isParseResult(data.result)) {
        const result = data.result;
        finish(() => resolve(result));
      } else if (data.status === "FAILED") {
        finish(() => reject(new Error("PARSER_WORKER_FAILED")));
      }
    };
    const onAbort = () => finish(() => reject(new DOMException("Cancelled", "AbortError")));
    const timeout = setTimeout(() => finish(() => reject(new Error("PARSER_TIMEOUT"))), timeoutMs);
    worker.addEventListener("message", onMessage);
    options.signal?.addEventListener("abort", onAbort, { once: true });
    worker.postMessage({ operation: "PARSE", requestId, bytes: transferable }, [transferable]);
  });
}

// src/offscreen/index.ts
chrome.runtime.onMessage.addListener(
  (message, _sender, sendResponse) => {
    if (!isRecord(message) || message.contractVersion !== CONTRACT_VERSION || message.type !== "PARSE_ATTACHMENT" || typeof message.sourceId !== "string" || typeof message.requestUrl !== "string") {
      return false;
    }
    void fetchAttachmentPayload(message.sourceId, message.requestUrl).then(
      async (payload) => {
        if (payload.result.status !== "fetched" || !payload.bytes) {
          sendResponse({ ok: false, errorCode: payload.result.errorCode ?? "FETCH_FAILED" });
          return;
        }
        try {
          const result = await parseInIsolatedWorker(
            payload.bytes,
            () => new Worker(chrome.runtime.getURL("parser-worker.js"))
          );
          sendResponse({ ok: true, result });
        } catch {
          sendResponse({ ok: false, errorCode: "PARSER_RUNTIME_FAILED" });
        }
      },
      () => sendResponse({ ok: false, errorCode: "PARSER_RUNTIME_FAILED" })
    );
    return true;
  }
);
//# sourceMappingURL=offscreen.js.map
