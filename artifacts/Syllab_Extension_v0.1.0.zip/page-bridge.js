"use strict";
(() => {
  // src/page-bridge/index.ts
  window.dispatchEvent(
    new CustomEvent("syllab:page-bridge-ready", {
      detail: { version: "0.1.0", capabilities: [] }
    })
  );
})();
//# sourceMappingURL=page-bridge.js.map
