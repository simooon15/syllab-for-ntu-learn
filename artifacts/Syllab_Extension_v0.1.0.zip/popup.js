// ../packages/contracts/dist/index.js
var CONTRACT_VERSION = 1;
function isRecord(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

// src/ai/client.ts
function normalizedLabel(candidate) {
  const label = ["title", "name", "label", "event", "description", "rule"].map((key) => candidate.proposedValue[key]).find((value) => typeof value === "string");
  return (label ?? JSON.stringify(candidate.proposedValue)).toLowerCase().replace(/\bexamination\b/g, "exam").replace(/\bwritten\b/g, "").replace(/[^a-z0-9]+/g, " ").replace(/\s+/g, " ").trim();
}
function normalizedCalendarDate(value) {
  const iso = value.match(/\b(\d{4})-(\d{2})-(\d{2})\b/);
  if (iso) return iso[0];
  const dayMonthYear = value.match(/\b(\d{1,2})\/(\d{1,2})\/(\d{4})\b/);
  if (dayMonthYear) {
    const day = Number(dayMonthYear[1]);
    const month = Number(dayMonthYear[2]);
    const year = Number(dayMonthYear[3]);
    const calendarDate2 = new Date(year, month - 1, day);
    if (calendarDate2.getFullYear() === year && calendarDate2.getMonth() === month - 1 && calendarDate2.getDate() === day) {
      return `${String(year).padStart(4, "0")}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
    }
    return null;
  }
  const naturalDate = value.match(
    /\b\d{1,2}\s+(?:jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:tember)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\s+\d{4}\b/i
  )?.[0];
  const parsed = Date.parse(naturalDate ?? value);
  if (Number.isNaN(parsed)) return null;
  const calendarDate = new Date(parsed);
  return [calendarDate.getFullYear(), calendarDate.getMonth() + 1, calendarDate.getDate()].map((part, index) => String(part).padStart(index === 0 ? 4 : 2, "0")).join("-");
}
function assessmentEntityKey(text) {
  const ca = text.match(/\b(?:ca\s*|continuous assessment\s*)(\d+)\b/i);
  if (ca?.[1]) return `ca${ca[1]}`;
  if (/\bfinal\s+(?:written\s+)?exam(?:ination)?\b/i.test(text)) return "final-exam";
  return null;
}
function dateEventKey(text, fallback) {
  if (/\bfinal\s+(?:written\s+)?exam(?:ination)?\b/i.test(text)) return "final-exam";
  if (/\bca\s*1\b|\bcontinuous assessment\s*1\b/i.test(text)) {
    if (/peer evaluation/i.test(text)) return "ca1-peer-evaluation";
    if (/batch\s*1/i.test(text)) return "ca1-presentation-batch1";
    if (/batch\s*2/i.test(text)) return "ca1-presentation-batch2";
    if (/role\s*play\s+script/i.test(text)) return "ca1-role-play-script";
    if (/power\s*point|slides?/i.test(text)) return "ca1-presentation-slides";
    return "ca1-submission";
  }
  if (/\bca\s*2\b|\bcontinuous assessment\s*2\b|\bmcq\b/i.test(text)) return "ca2-test";
  if (/\bca\s*3\b|\bcontinuous assessment\s*3\b|case study/i.test(text)) {
    return "ca3-case-study";
  }
  if (/project background|procurement scenario|scenario.*form/i.test(text)) return "scenario-form";
  return fallback;
}
function semanticKey(candidate) {
  const label = normalizedLabel(candidate);
  const proposedText = JSON.stringify(candidate.proposedValue);
  if (candidate.kind === "assessment") {
    return `assessment:${assessmentEntityKey(proposedText) ?? label}`;
  }
  const relationshipKey = candidate.scope === "assessment" ? candidate.appliesToAssessmentKey : candidate.scope === "course" ? "course" : candidate.appliesToAssessmentKey ?? "unresolved";
  if (candidate.kind !== "important_date") {
    return `${candidate.kind}:${label}:${relationshipKey ?? "unresolved"}`;
  }
  const dateValue = Object.entries(candidate.proposedValue).find(
    ([key, value]) => /date|when/i.test(key) && typeof value === "string"
  )?.[1];
  const normalizedDate2 = typeof dateValue === "string" ? normalizedCalendarDate(dateValue) ?? dateValue : "";
  return `${candidate.kind}:${dateEventKey(proposedText, label)}:${normalizedDate2}:${relationshipKey ?? "unresolved"}`;
}
var identityFields = /* @__PURE__ */ new Set(["title", "name", "label", "event", "what", "description"]);
function valuesEqual(left, right) {
  return JSON.stringify(left) === JSON.stringify(right);
}
function mergeProposedValues(preferred, additional) {
  const value = structuredClone(preferred);
  const conflicts = {};
  for (const [key, incoming] of Object.entries(additional)) {
    if (!(key in value)) {
      value[key] = structuredClone(incoming);
      continue;
    }
    const current = value[key];
    if (valuesEqual(current, incoming)) continue;
    if (identityFields.has(key)) continue;
    if (/date|when/i.test(key) && typeof current === "string" && typeof incoming === "string") {
      if (normalizedCalendarDate(current) === normalizedCalendarDate(incoming)) continue;
    }
    conflicts[key] = [structuredClone(current), structuredClone(incoming)];
  }
  return { value, conflicts };
}
function normalizedRelationshipText(value) {
  return value.toLowerCase().replace(/peer assessment/g, "peer evaluation").replace(/[^a-z0-9]+/g, " ").replace(/\s+/g, " ").trim();
}
function stringsFromValue(value) {
  if (typeof value === "string") return [value];
  if (Array.isArray(value)) return value.flatMap((item) => stringsFromValue(item));
  if (!isRecord(value)) return [];
  return Object.values(value).flatMap((item) => stringsFromValue(item));
}
function assessmentIdentities(candidates) {
  return candidates.filter((candidate) => candidate.kind === "assessment").map((candidate) => {
    const key = semanticKey(candidate);
    const aliases = stringsFromValue(candidate.proposedValue).map(normalizedRelationshipText).filter((value) => value.length >= 4 && !/^\d+(?:\s*(?:marks?|%))?$/.test(value));
    return { key, aliases: [...new Set(aliases)] };
  });
}
function explicitParentKey(text) {
  const entity = assessmentEntityKey(text);
  return entity ? `assessment:${entity}` : null;
}
function aliasParentKey(text, identities) {
  const normalized = normalizedRelationshipText(text);
  const tokens = new Set(normalized.split(" ").filter((token) => token.length > 1));
  const matches = /* @__PURE__ */ new Set();
  for (const identity of identities) {
    if (identity.aliases.some((alias) => {
      if (normalized.includes(alias) || alias.includes(normalized)) return true;
      const aliasTokens = new Set(alias.split(" ").filter((token) => token.length > 1));
      return tokens.size >= 3 && [...tokens].every((token) => aliasTokens.has(token));
    })) {
      matches.add(identity.key);
    }
  }
  return matches.size === 1 ? [...matches][0] ?? null : null;
}
function isExplicitCourseRule(text) {
  return /\b(?:all course materials|all written assignments|students are expected|deadline extensions?|absence from class|attendance is mandatory|academic integrity|course-wide|all assignments)\b/i.test(
    text
  );
}
function migrateCandidateRelationship(candidate, identities) {
  const next = structuredClone(candidate);
  if (next.kind === "assessment" || next.scope === "course" && !next.appliesToAssessmentKey) {
    return next;
  }
  if (next.scope === "assessment" && next.appliesToAssessmentKey) {
    if (identities.some((identity) => identity.key === next.appliesToAssessmentKey)) return next;
    if (identities.length === 0) return next;
    const remappedParent = aliasParentKey(
      next.appliesToAssessmentKey.replace(/^assessment:/, "").replace(/-/g, " "),
      identities
    );
    if (remappedParent) {
      next.appliesToAssessmentKey = remappedParent;
      return next;
    }
    delete next.scope;
    next.status = "NeedsReview";
    next.reviewReason ??= "The referenced parent Assessment was not found. Choose the correct Assessment before confirming.";
    return next;
  }
  const text = JSON.stringify(next.proposedValue);
  const parentKey = explicitParentKey(text) ?? aliasParentKey(text, identities);
  if (parentKey) {
    next.scope = "assessment";
    next.appliesToAssessmentKey = parentKey;
    return next;
  }
  if (next.kind === "important_date" || isExplicitCourseRule(text)) {
    next.scope = "course";
    delete next.appliesToAssessmentKey;
    return next;
  }
  delete next.scope;
  delete next.appliesToAssessmentKey;
  next.status = "NeedsReview";
  next.reviewReason ??= "It is unclear whether this requirement is course-wide or belongs to an Assessment.";
  return next;
}
function removeFalseUngradedRisk(candidate) {
  const next = structuredClone(candidate);
  if (next.kind === "assessment" && next.status === "NeedsReview" && next.reviewReason === "The source does not clearly establish that this item is graded." && Object.entries(next.proposedValue).some(
    ([key, value]) => /^(?:weight|marks?|score|grade)$/i.test(key) && (typeof value === "number" && Number.isFinite(value) || typeof value === "string" && /\d/.test(value))
  )) {
    next.status = "Detected";
    delete next.reviewReason;
  }
  return next;
}
function mergeCandidateRecords(candidates) {
  const identities = assessmentIdentities(candidates);
  const merged = /* @__PURE__ */ new Map();
  for (const candidate of candidates) {
    const isUnreviewed = candidate.status === "Detected" || candidate.status === "NeedsReview";
    const next = isUnreviewed ? removeFalseUngradedRisk(migrateCandidateRelationship(candidate, identities)) : structuredClone(candidate);
    if (isUnreviewed) next.semanticKey = semanticKey(next);
    const mapKey = isUnreviewed ? next.semanticKey : `${next.semanticKey}:${next.candidateId}`;
    const existing = merged.get(mapKey);
    if (!existing) {
      merged.set(mapKey, next);
      continue;
    }
    const existingSize = JSON.stringify(existing.proposedValue).length;
    const nextSize = JSON.stringify(next.proposedValue).length;
    const preferred = nextSize > existingSize ? next : existing;
    const additional = preferred === existing ? next : existing;
    const combined = mergeProposedValues(preferred.proposedValue, additional.proposedValue);
    const evidenceRefs = [...existing.evidenceRefs];
    for (const reference of next.evidenceRefs) {
      if (!evidenceRefs.some(
        (current) => current.sourceId === reference.sourceId && current.locator === reference.locator
      )) {
        evidenceRefs.push(reference);
      }
    }
    const result = structuredClone(preferred);
    result.semanticKey = next.semanticKey;
    result.proposedValue = combined.value;
    const unresolvedFields = {
      ...structuredClone(existing.unresolvedFields ?? {}),
      ...structuredClone(next.unresolvedFields ?? {}),
      ...combined.conflicts
    };
    if (Object.keys(unresolvedFields).length > 0) result.unresolvedFields = unresolvedFields;
    result.evidenceRefs = evidenceRefs;
    const reviewReason = existing.reviewReason ?? next.reviewReason;
    if (reviewReason) result.reviewReason = reviewReason;
    if (Object.keys(combined.conflicts).length > 0) {
      result.status = "NeedsReview";
      result.reviewReason ??= "Conflicting values were found for the same course fact.";
    } else if (existing.status === "NeedsReview" || next.status === "NeedsReview") {
      result.status = "NeedsReview";
    }
    merged.set(mapKey, result);
  }
  return [...merged.values()];
}

// src/brief/state.ts
function normalizedAssessmentKey(value) {
  return value.replace(/^assessment:/, "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
}
function resolveParentId(requestedKey, parentIds) {
  if (!requestedKey) return void 0;
  const exact = parentIds.get(requestedKey);
  if (exact) return exact;
  const requested = normalizedAssessmentKey(requestedKey);
  if (!requested) return void 0;
  const aliases = [...parentIds.entries()].filter(([key]) => {
    const available = normalizedAssessmentKey(key);
    return available === requested || available.includes(requested) || requested.includes(available);
  });
  return aliases.length === 1 ? aliases[0]?.[1] : void 0;
}
function briefItemsFromReview(courseId, candidates, unresolvedFields = {}, now = /* @__PURE__ */ new Date(), existingItems = []) {
  const confirmed = candidates.filter(
    (candidate) => candidate.status === "Confirmed" || candidate.status === "EditedConfirmed"
  );
  const createItem = (candidate, parentBriefItemId) => {
    const unresolved = unresolvedFields[candidate.candidateId] ?? candidate.unresolvedFields ?? {};
    const currentValue = Object.fromEntries(
      Object.entries(structuredClone(candidate.confirmedValue ?? candidate.proposedValue)).filter(
        ([field]) => !(field in unresolved)
      )
    );
    const fieldStates = {};
    for (const [field, values] of Object.entries(unresolved)) {
      fieldStates[field] = {
        status: "Unresolved",
        candidateValues: structuredClone(values),
        evidenceRefs: structuredClone(candidate.evidenceRefs)
      };
    }
    return {
      briefItemId: `candidate:${candidate.candidateId}`,
      courseId,
      kind: candidate.kind,
      ...candidate.scope ? { scope: candidate.scope } : {},
      ...parentBriefItemId ? { parentBriefItemId } : {},
      origin: "candidate",
      status: candidate.status,
      currentValue,
      fieldStates,
      sourceCandidateRefs: [candidate.candidateId],
      evidenceRefs: structuredClone(candidate.evidenceRefs),
      semanticKey: candidate.semanticKey,
      ...candidate.appliesToAssessmentKey ? { parentSemanticKey: candidate.appliesToAssessmentKey } : {},
      updatedAt: now.toISOString()
    };
  };
  const items = [];
  const parentIds = /* @__PURE__ */ new Map();
  for (const item of existingItems) {
    if (item.courseId === courseId && item.kind === "assessment" && item.semanticKey) {
      parentIds.set(item.semanticKey, item.briefItemId);
    }
  }
  for (const candidate of confirmed.filter((item) => item.kind === "assessment")) {
    const item = createItem(candidate);
    items.push(item);
    parentIds.set(candidate.semanticKey, item.briefItemId);
  }
  for (const candidate of confirmed.filter((item) => item.kind !== "assessment")) {
    if (candidate.scope === "assessment") {
      const parentId = resolveParentId(candidate.appliesToAssessmentKey, parentIds);
      if (!parentId) continue;
      items.push(createItem(candidate, parentId));
      continue;
    }
    items.push(createItem(candidate));
  }
  return items;
}
function resolveBriefField(items, briefItemId, field, value, now = /* @__PURE__ */ new Date()) {
  return items.map((item) => {
    if (item.briefItemId !== briefItemId) return structuredClone(item);
    const state = item.fieldStates[field];
    if (!state || state.status !== "Unresolved") throw new Error("BRIEF_FIELD_NOT_UNRESOLVED");
    return {
      ...structuredClone(item),
      currentValue: { ...structuredClone(item.currentValue), [field]: structuredClone(value) },
      fieldStates: {
        ...structuredClone(item.fieldStates),
        [field]: {
          status: "Confirmed",
          value: structuredClone(value),
          evidenceRefs: structuredClone(state.evidenceRefs)
        }
      },
      updatedAt: now.toISOString()
    };
  });
}
function editBriefItem(items, briefItemId, value, now = /* @__PURE__ */ new Date()) {
  const targetIndex = items.findIndex((item) => item.briefItemId === briefItemId);
  if (targetIndex < 0) throw new Error("BRIEF_ITEM_NOT_FOUND");
  return items.map((item, index) => {
    if (index !== targetIndex) return structuredClone(item);
    return {
      ...structuredClone(item),
      status: "EditedConfirmed",
      currentValue: structuredClone(value),
      updatedAt: now.toISOString()
    };
  });
}
function addUserBriefItem(items, courseId, kind, value, now = /* @__PURE__ */ new Date()) {
  return [
    ...structuredClone(items),
    {
      briefItemId: crypto.randomUUID(),
      courseId,
      kind,
      ...kind === "assessment" ? {} : { scope: "course" },
      origin: "user_added",
      status: "UserAddedConfirmed",
      currentValue: structuredClone(value),
      fieldStates: {},
      sourceCandidateRefs: [],
      evidenceRefs: [],
      updatedAt: now.toISOString()
    }
  ];
}

// src/repository/local-database.ts
var CANDIDATES_STORE = "candidates";
var REVIEW_PROGRESS_STORE = "reviewProgress";
var BRIEF_ITEMS_STORE = "briefItems";
var PARSED_SOURCES_STORE = "parsedSources";
var NORMALIZED_UNITS_STORE = "normalizedUnits";
function requestResult(request) {
  return new Promise((resolve, reject) => {
    request.addEventListener("success", () => resolve(request.result), { once: true });
    request.addEventListener(
      "error",
      () => reject(request.error ?? new Error("INDEXED_DB_ERROR")),
      {
        once: true
      }
    );
  });
}
function transactionComplete(transaction) {
  return new Promise((resolve, reject) => {
    transaction.addEventListener("complete", () => resolve(), { once: true });
    transaction.addEventListener(
      "abort",
      () => reject(transaction.error ?? new Error("INDEXED_DB_ABORT")),
      {
        once: true
      }
    );
    transaction.addEventListener(
      "error",
      () => reject(transaction.error ?? new Error("INDEXED_DB_ERROR")),
      {
        once: true
      }
    );
  });
}
async function openLocalDatabase() {
  const request = indexedDB.open("syllab-local", 4);
  request.addEventListener("upgradeneeded", () => {
    const database = request.result;
    if (!database.objectStoreNames.contains(CANDIDATES_STORE)) {
      const candidates = database.createObjectStore(CANDIDATES_STORE, { keyPath: "candidateId" });
      candidates.createIndex("scanId", "scanId", { unique: false });
    }
    if (!database.objectStoreNames.contains(REVIEW_PROGRESS_STORE)) {
      database.createObjectStore(REVIEW_PROGRESS_STORE, { keyPath: "scanId" });
    }
    if (!database.objectStoreNames.contains(BRIEF_ITEMS_STORE)) {
      const briefs = database.createObjectStore(BRIEF_ITEMS_STORE, { keyPath: "briefItemId" });
      briefs.createIndex("courseId", "courseId", { unique: false });
    }
    if (!database.objectStoreNames.contains(PARSED_SOURCES_STORE)) {
      const parsed = database.createObjectStore(PARSED_SOURCES_STORE, { keyPath: "recordId" });
      parsed.createIndex("scanId", "scanId", { unique: false });
    }
    if (!database.objectStoreNames.contains(NORMALIZED_UNITS_STORE)) {
      const normalized = database.createObjectStore(NORMALIZED_UNITS_STORE, { keyPath: "unitId" });
      normalized.createIndex("scanId", "scanId", { unique: false });
    }
  });
  return requestResult(request);
}

// src/brief/repository.ts
var IndexedDbBriefRepository = class {
  async listAllItems() {
    const database = await openLocalDatabase();
    try {
      const transaction = database.transaction(BRIEF_ITEMS_STORE, "readonly");
      const items = await requestResult(
        transaction.objectStore(BRIEF_ITEMS_STORE).getAll()
      );
      await transactionComplete(transaction);
      return items;
    } finally {
      database.close();
    }
  }
  async upsertCourseItems(items) {
    if (items.length === 0) return;
    const database = await openLocalDatabase();
    try {
      const transaction = database.transaction(BRIEF_ITEMS_STORE, "readwrite");
      const store = transaction.objectStore(BRIEF_ITEMS_STORE);
      for (const item of items) store.put(structuredClone(item));
      await transactionComplete(transaction);
    } finally {
      database.close();
    }
  }
  async replaceCourseItems(courseId, items) {
    const database = await openLocalDatabase();
    try {
      const transaction = database.transaction(BRIEF_ITEMS_STORE, "readwrite");
      const store = transaction.objectStore(BRIEF_ITEMS_STORE);
      const existing = await requestResult(store.index("courseId").getAllKeys(courseId));
      for (const key of existing) store.delete(key);
      for (const item of items) store.put(structuredClone(item));
      await transactionComplete(transaction);
    } finally {
      database.close();
    }
  }
  async listCourseItems(courseId) {
    const database = await openLocalDatabase();
    try {
      const transaction = database.transaction(BRIEF_ITEMS_STORE, "readonly");
      const items = await requestResult(
        transaction.objectStore(BRIEF_ITEMS_STORE).index("courseId").getAll(courseId)
      );
      await transactionComplete(transaction);
      return items;
    } finally {
      database.close();
    }
  }
};

// src/repository/course-index-repository.ts
var COURSE_INDEX_KEY = "syllab.courseIndex";
var SCAN_SUMMARIES_KEY = "syllab.scanSummaries";
function readArray(value) {
  return Array.isArray(value) ? value : [];
}
function isResumableStatus(status) {
  return status === "Interrupted" || status === "Failed";
}
var CourseIndexRepository = class {
  constructor(storage) {
    this.storage = storage;
  }
  async listCourses() {
    const result = await this.storage.get(COURSE_INDEX_KEY);
    return readArray(result[COURSE_INDEX_KEY]);
  }
  async findCourse(courseId) {
    const courses = await this.listCourses();
    return courses.find((course) => course.courseId === courseId) ?? null;
  }
  async findCourseByScanFallback(scanId) {
    const scans = await this.listScans();
    const scan = scans.find((item) => item.scanId === scanId);
    return scan ? this.findCourse(scan.courseId) : null;
  }
  async upsertCourse(course) {
    const courses = await this.listCourses();
    await this.storage.set({
      [COURSE_INDEX_KEY]: [course, ...courses.filter((item) => item.courseId !== course.courseId)]
    });
  }
  async findEntryScan(courseId) {
    const result = await this.storage.get(SCAN_SUMMARIES_KEY);
    const scans = readArray(result[SCAN_SUMMARIES_KEY]).filter(
      (scan) => scan.courseId === courseId
    );
    const isRunning = (scan) => scan.status === "Scanning" || scan.status === "WaitingForPermission";
    const isResumable = (scan) => isResumableStatus(scan.status) && scan.recoverable;
    const newest = scans[0];
    if (newest && (isRunning(newest) || isResumable(newest))) return newest;
    return scans.find(isRunning) ?? null;
  }
  async listScans() {
    const result = await this.storage.get(SCAN_SUMMARIES_KEY);
    return readArray(result[SCAN_SUMMARIES_KEY]);
  }
  async replaceScans(scans) {
    await this.storage.set({ [SCAN_SUMMARIES_KEY]: structuredClone(scans) });
  }
  async resumeScan(scanId) {
    const scans = await this.listScans();
    const target = scans.find((scan) => scan.scanId === scanId);
    if (!target || !isResumableStatus(target.status) || !target.recoverable) return null;
    const resumed = { ...target, status: "Scanning", recoverable: true };
    await this.replaceScans(scans.map((scan) => scan.scanId === scanId ? resumed : scan));
    return resumed;
  }
};

// src/review/relationship.ts
function assessmentLabel(candidate) {
  const value = candidate.proposedValue;
  for (const key of ["identifier", "name", "title", "label"]) {
    if (typeof value[key] === "string" && value[key].trim().length > 0) return value[key].trim();
  }
  return null;
}
function candidateRelationshipLabel(candidate, candidates) {
  if (candidate.scope === "course") return "Course-level";
  if (candidate.scope !== "assessment" || !candidate.appliesToAssessmentKey) return null;
  const parent = candidates.find(
    (item) => item.kind === "assessment" && item.semanticKey === candidate.appliesToAssessmentKey
  );
  const label = parent ? assessmentLabel(parent) : null;
  const fallback = candidate.appliesToAssessmentKey.replace(/^assessment:/, "").replace(/-/g, " ").toUpperCase();
  return `Applies to ${label ?? fallback}`;
}

// src/review/repository.ts
var IndexedDbReviewRepository = class {
  async save(scanId, candidates, progress) {
    const database = await openLocalDatabase();
    try {
      const transaction = database.transaction(
        [CANDIDATES_STORE, REVIEW_PROGRESS_STORE],
        "readwrite"
      );
      const candidateStore = transaction.objectStore(CANDIDATES_STORE);
      const existing = await requestResult(candidateStore.index("scanId").getAllKeys(scanId));
      for (const key of existing) candidateStore.delete(key);
      for (const candidate of candidates) candidateStore.put(structuredClone(candidate));
      transaction.objectStore(REVIEW_PROGRESS_STORE).put(structuredClone(progress));
      await transactionComplete(transaction);
    } finally {
      database.close();
    }
  }
  async load(scanId) {
    const database = await openLocalDatabase();
    try {
      const transaction = database.transaction(
        [CANDIDATES_STORE, REVIEW_PROGRESS_STORE],
        "readonly"
      );
      const [candidates, progress] = await Promise.all([
        requestResult(
          transaction.objectStore(CANDIDATES_STORE).index("scanId").getAll(scanId)
        ),
        requestResult(transaction.objectStore(REVIEW_PROGRESS_STORE).get(scanId))
      ]);
      await transactionComplete(transaction);
      return { candidates, progress: progress ?? null };
    } finally {
      database.close();
    }
  }
};

// src/review/state.ts
function updateCandidate(candidates, candidateId, update) {
  const targetIndex = candidates.findIndex((candidate) => candidate.candidateId === candidateId);
  if (targetIndex < 0) throw new Error("REVIEW_CANDIDATE_NOT_FOUND");
  return candidates.map(
    (candidate, index) => index === targetIndex ? update(structuredClone(candidate)) : structuredClone(candidate)
  );
}
function confirmCandidate(candidates, candidateId, now = /* @__PURE__ */ new Date()) {
  return updateCandidate(candidates, candidateId, (candidate) => ({
    ...candidate,
    status: "Confirmed",
    confirmedValue: structuredClone(candidate.proposedValue),
    confirmedAt: now.toISOString()
  }));
}
function editAndConfirmCandidate(candidates, candidateId, editedValue, now = /* @__PURE__ */ new Date()) {
  return updateCandidate(candidates, candidateId, (candidate) => {
    const next = {
      ...candidate,
      status: "EditedConfirmed",
      confirmedValue: structuredClone(editedValue),
      confirmedAt: now.toISOString()
    };
    delete next.unresolvedFields;
    return next;
  });
}
function ignoreCandidate(candidates, candidateId, now = /* @__PURE__ */ new Date()) {
  return updateCandidate(candidates, candidateId, (candidate) => ({
    ...candidate,
    status: "Ignored",
    ignoredAt: now.toISOString()
  }));
}
function assignCandidateRelationship(candidates, candidateId, scope, appliesToAssessmentKey) {
  if (scope === "assessment" && !appliesToAssessmentKey) {
    throw new Error("ASSESSMENT_RELATIONSHIP_PARENT_REQUIRED");
  }
  return updateCandidate(candidates, candidateId, (candidate) => {
    if (candidate.kind === "assessment") throw new Error("ASSESSMENT_CANNOT_BE_CHILD");
    const next = { ...candidate, scope };
    if (scope === "assessment" && appliesToAssessmentKey) {
      next.appliesToAssessmentKey = appliesToAssessmentKey;
    } else {
      delete next.appliesToAssessmentKey;
    }
    if (next.reviewReason?.includes("referenced parent Assessment was not found")) {
      delete next.reviewReason;
    }
    return next;
  });
}
function confirmDetectedCategory(candidates, category, now = /* @__PURE__ */ new Date()) {
  return candidates.map(
    (candidate) => candidate.kind === category && candidate.status === "Detected" ? {
      ...structuredClone(candidate),
      status: "Confirmed",
      confirmedValue: structuredClone(candidate.proposedValue),
      confirmedAt: now.toISOString()
    } : structuredClone(candidate)
  );
}
function reviewProgress(scanId, candidates) {
  const detected = candidates.filter((candidate) => candidate.status === "Detected").length;
  const needsReview = candidates.filter((candidate) => candidate.status === "NeedsReview").length;
  return {
    scanId,
    total: candidates.length,
    reviewed: candidates.length - detected - needsReview,
    detected,
    needsReview,
    complete: detected === 0 && needsReview === 0
  };
}

// src/popup/entry-router.ts
function resolveEntryRoute(input) {
  if (!input.context) return { surface: "saved-courses" };
  if (input.entryScan) {
    const state = input.entryScan.status === "Scanning" ? "scanning" : input.entryScan.status === "WaitingForPermission" ? "waiting-for-permission" : "interrupted";
    return {
      surface: "scan",
      state,
      courseId: input.context.courseId,
      scanId: input.entryScan.scanId,
      ...input.entryScan.phase ? { phase: input.entryScan.phase } : {}
    };
  }
  if (!input.course?.hasEffectiveScan) {
    return { surface: "scan", state: "ready", courseId: input.context.courseId };
  }
  return { surface: "course-brief", courseId: input.context.courseId };
}

// src/popup/entry-runtime.ts
async function readCurrentCourseContext() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  const activeTab = tabs[0];
  if (activeTab?.id === void 0 || !activeTab.url?.startsWith("https://ntulearn.ntu.edu.sg/")) {
    return null;
  }
  try {
    const response = await chrome.tabs.sendMessage(activeTab.id, {
      contractVersion: CONTRACT_VERSION,
      type: "GET_COURSE_CONTEXT"
    });
    if (!isRecord(response) || !isRecord(response.context)) return null;
    if (typeof response.context.courseId !== "string" || typeof response.context.route !== "string") {
      return null;
    }
    return {
      courseId: response.context.courseId,
      route: response.context.route,
      ...typeof response.context.courseCode === "string" ? { courseCode: response.context.courseCode } : {},
      ...typeof response.context.courseName === "string" ? { courseName: response.context.courseName } : {}
    };
  } catch {
    return null;
  }
}
async function resolveCurrentEntry() {
  const context = await readCurrentCourseContext();
  if (!context) return { surface: "saved-courses" };
  const repository = new CourseIndexRepository(chrome.storage.local);
  const [course, entryScan] = await Promise.all([
    repository.findCourse(context.courseId),
    repository.findEntryScan(context.courseId)
  ]);
  return resolveEntryRoute({ context, course, entryScan });
}

// src/popup/scan-errors.ts
var scanErrorCopy = {
  SCAN_INTERRUPTED: "This scan was interrupted while it was running. Open the scan again and use Continue scan to resume from the saved checkpoint.",
  SCAN_NOT_RECOVERABLE: "This scan can no longer be resumed from its checkpoint. Open the course again to start a fresh scan.",
  SCAN_NOT_FOUND: "That scan record no longer exists. Open the course again to start a fresh scan.",
  REVIEW_ALREADY_STARTED: "This scan has already been reviewed. Use Scan again if you want Syllab to check the course for changes.",
  DISCOVERY_NOT_COMPLETE: "Discovery did not finish for this scan. Continue discovery before moving to the next stage.",
  DISCOVERY_CHECKPOINT_NOT_FOUND: "The saved discovery checkpoint for this scan is missing. Start a new scan for this course.",
  STORAGE_UNAVAILABLE: "Syllab could not read its local storage. Reload the extension, then try again."
};
function describeScanError(message) {
  return scanErrorCopy[message] ?? message;
}
function scanErrorFrom(response, fallback) {
  const message = isRecord(response) && typeof response.error === "string" ? response.error : fallback;
  return new Error(describeScanError(message));
}

// src/calendar/query.ts
var dateField = /(?:date|deadline|due|when|start)/i;
var timeField = /(?:time|startTime)/i;
function normalizedDate(value) {
  if (typeof value !== "string") return null;
  const iso = value.match(/\b(\d{4})-(\d{2})-(\d{2})\b/);
  if (iso) return iso[0];
  const slash = value.match(/\b(\d{1,2})\/(\d{1,2})\/(\d{4})\b/);
  if (slash) {
    const day = Number(slash[1]);
    const month = Number(slash[2]);
    const year = Number(slash[3]);
    const checked = new Date(year, month - 1, day);
    if (checked.getFullYear() === year && checked.getMonth() === month - 1 && checked.getDate() === day) {
      return `${String(year).padStart(4, "0")}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
    }
  }
  const parsed = Date.parse(value);
  if (Number.isNaN(parsed)) return null;
  const date = new Date(parsed);
  return `${String(date.getFullYear()).padStart(4, "0")}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}
function firstString(value, keys) {
  return Object.entries(value).find(
    ([key, candidate]) => keys.test(key) && typeof candidate === "string"
  )?.[1];
}
function eventTitle(item, parents) {
  const value = item.currentValue;
  const own = firstString(value, /^(?:title|name|label|event|assessment|what|description)$/i);
  const parent = item.parentBriefItemId ? parents.get(item.parentBriefItemId) : void 0;
  const parentName = parent ? firstString(parent.currentValue, /^(?:title|name|label|assessment|identifier)$/i) : void 0;
  return own ?? parentName ?? (item.kind === "assessment" ? "Assessment" : "Important date");
}
function calendarEventsFromBrief(items) {
  const parents = new Map(items.map((item) => [item.briefItemId, item]));
  const seen = /* @__PURE__ */ new Set();
  const events = [];
  for (const item of items) {
    if (Object.entries(item.fieldStates).some(
      ([field, state]) => dateField.test(field) && state.status === "Unresolved"
    )) {
      continue;
    }
    const rawDate = firstString(item.currentValue, dateField);
    const date = normalizedDate(rawDate);
    if (!date) continue;
    const title = eventTitle(item, parents);
    const time = firstString(item.currentValue, timeField)?.match(
      /\b([01]\d|2[0-3]):([0-5]\d)\b/
    )?.[0];
    const dedupeKey = `${title.toLowerCase()}|${date}|${time ?? ""}|${item.parentBriefItemId ?? "course"}`;
    if (seen.has(dedupeKey)) continue;
    seen.add(dedupeKey);
    events.push({
      eventId: `${item.briefItemId}:${date}:${time ?? "all-day"}`,
      title,
      date,
      ...time ? { time } : {},
      description: `Syllab ${item.kind.replace("_", " ")}`
    });
  }
  return events;
}

// src/calendar/ics.ts
function escapeText(value) {
  return value.replace(/\\/g, "\\\\").replace(/\r?\n/g, "\\n").replace(/,/g, "\\,").replace(/;/g, "\\;");
}
function stableHash(value) {
  let hash = 2166136261;
  for (const character of value) {
    hash ^= character.codePointAt(0) ?? 0;
    hash = Math.imul(hash, 16777619);
  }
  return (hash >>> 0).toString(16).padStart(8, "0");
}
function foldLine(line) {
  const lines = [];
  let current = "";
  let bytes = 0;
  for (const character of line) {
    const size = new TextEncoder().encode(character).length;
    if (bytes + size > 75) {
      lines.push(current);
      current = ` ${character}`;
      bytes = 1 + size;
    } else {
      current += character;
      bytes += size;
    }
  }
  lines.push(current);
  return lines.join("\r\n");
}
function compactDate(date) {
  return date.replaceAll("-", "");
}
function nextDate(date) {
  const [year, month, day] = date.split("-").map(Number);
  const next = new Date(Date.UTC(year ?? 0, (month ?? 1) - 1, day ?? 1));
  next.setUTCDate(next.getUTCDate() + 1);
  return next.toISOString().slice(0, 10).replaceAll("-", "");
}
function serializeCalendar(courseId, events, generatedAt = /* @__PURE__ */ new Date()) {
  const timestamp = generatedAt.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}Z$/, "Z");
  const lines = [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//Syllab//NTU Learn//EN",
    "CALSCALE:GREGORIAN"
  ];
  for (const event of events) {
    lines.push("BEGIN:VEVENT");
    lines.push(`UID:${stableHash(`${courseId}|${event.eventId}`)}@syllab.local`);
    lines.push(`DTSTAMP:${timestamp}`);
    if (event.time) {
      lines.push(
        `DTSTART;TZID=Asia/Singapore:${compactDate(event.date)}T${event.time.replace(":", "")}00`
      );
    } else {
      lines.push(`DTSTART;VALUE=DATE:${compactDate(event.date)}`);
      lines.push(`DTEND;VALUE=DATE:${nextDate(event.date)}`);
    }
    lines.push(`SUMMARY:${escapeText(event.title)}`);
    lines.push(`DESCRIPTION:${escapeText(event.description)}`);
    lines.push("END:VEVENT");
  }
  lines.push("END:VCALENDAR");
  return `${lines.map(foldLine).join("\r\n")}\r
`;
}

// src/popup/index.ts
var surfaces = [
  { id: "saved-courses", label: "Saved Courses" },
  { id: "scan", label: "Scan" },
  { id: "review", label: "Review" },
  { id: "course-brief", label: "Course Brief" }
];
function parseParseState(value) {
  if (!isRecord(value)) return null;
  return {
    parsed: typeof value.parsed === "number" ? value.parsed : 0,
    partial: typeof value.partial === "number" ? value.partial : 0,
    unsupported: typeof value.unsupported === "number" ? value.unsupported : 0,
    failed: typeof value.failed === "number" ? value.failed : 0,
    complete: value.complete === true
  };
}
function parseNormalizeState(value) {
  if (!isRecord(value)) return null;
  return {
    unitCount: typeof value.unitCount === "number" ? value.unitCount : 0,
    duplicateCount: typeof value.duplicateCount === "number" ? value.duplicateCount : 0,
    sourceCount: typeof value.sourceCount === "number" ? value.sourceCount : 0,
    complete: value.complete === true
  };
}
function viewCopy(route) {
  if (route.surface === "saved-courses") {
    return {
      title: "Your course shelf",
      lede: "Open an NTU Learn course to scan it, or return to a course brief you have already built.",
      statusLabel: "Current context"
    };
  }
  if (route.surface === "course-brief") {
    return {
      title: "Course brief",
      lede: "Confirmed course facts stay here. Sources remain available when you need to check the evidence.",
      statusLabel: "Brief status"
    };
  }
  if (route.surface === "review") {
    return {
      title: "Review course facts",
      lede: "Check uncertain items first, then confirm detected facts by category or one at a time.",
      statusLabel: "Review progress"
    };
  }
  if (route.state === "ready") {
    return {
      title: "Scan this course",
      lede: "Find pages, announcements, assignments and supported documents. Nothing becomes a fact until you review it.",
      statusLabel: "Ready"
    };
  }
  if (route.state === "waiting-for-permission") {
    return {
      title: "Permission needed",
      lede: "One attachment host needs access. You can allow this exact site or continue with the other sources.",
      statusLabel: "Waiting for permission"
    };
  }
  return {
    title: route.phase === "fetch" ? "Sources discovered" : "Scan in progress",
    lede: route.phase === "fetch" ? "Discovery is saved. The next stage will read supported content without changing NTU Learn." : "Syllab is following the course structure and saving each completed step as it goes.",
    statusLabel: "Scan record"
  };
}
function parseFetchState(value) {
  if (!isRecord(value)) return null;
  const pending = value.pendingOrigin;
  if (pending !== null && !isRecord(pending)) return null;
  const stringArray = (key) => Array.isArray(value[key]) ? value[key].filter((item) => typeof item === "string") : [];
  const signatureCounts = isRecord(value.signatureCounts) ? Object.fromEntries(
    Object.entries(value.signatureCounts).filter(
      (entry) => typeof entry[1] === "number"
    )
  ) : {};
  return {
    pendingOrigin: pending && typeof pending.origin === "string" && typeof pending.permissionPattern === "string" && typeof pending.sourceCount === "number" ? {
      origin: pending.origin,
      permissionPattern: pending.permissionPattern,
      sourceCount: pending.sourceCount
    } : null,
    fetchedCount: typeof value.fetchedCount === "number" ? value.fetchedCount : 0,
    deniedCount: typeof value.deniedCount === "number" ? value.deniedCount : 0,
    failedCount: typeof value.failedCount === "number" ? value.failedCount : 0,
    signatureCounts,
    finalOrigins: stringArray("finalOrigins"),
    grantedOrigins: stringArray("grantedOrigins"),
    deniedOrigins: stringArray("deniedOrigins"),
    suspiciousCount: typeof value.suspiciousCount === "number" ? value.suspiciousCount : 0,
    complete: value.complete === true
  };
}
function fetchStateLabel(outcome, state) {
  if (!state) return `Fetch ${String(outcome)}`;
  const signatures = Object.entries(state.signatureCounts).map(([name, count]) => `${String(count)} ${name}`).join(", ");
  return [
    `Fetch ${String(outcome)}`,
    `${String(state.fetchedCount)} fetched`,
    `${String(state.deniedCount)} denied`,
    `${String(state.failedCount)} failed`,
    signatures || "no file signatures",
    `final origins ${state.finalOrigins.join(", ") || "none"}`,
    `runtime origins ${state.grantedOrigins.join(", ") || "none"}`,
    `${String(state.suspiciousCount)} incomplete byte results`
  ].join(" \xB7 ");
}
async function beginFetch(route) {
  if (!route.scanId) throw new Error("Fetch checkpoint is missing");
  render({ ...route, state: "scanning", phase: "fetch" }, "Reading discovered sources\u2026");
  const response = await chrome.runtime.sendMessage({
    contractVersion: CONTRACT_VERSION,
    type: "START_FETCH",
    scanId: route.scanId
  });
  if (!isRecord(response) || typeof response.error === "string") {
    throw scanErrorFrom(response, "Source fetch could not start");
  }
  const state = parseFetchState(response.state);
  const waiting = response.outcome === "WaitingForPermission";
  render(
    {
      ...route,
      state: waiting ? "waiting-for-permission" : "scanning",
      phase: waiting ? "fetch" : "parse"
    },
    waiting ? "Choose how to handle this attachment host" : fetchStateLabel(response.outcome, state),
    false,
    state
  );
}
async function beginParse(route) {
  if (!route.scanId) throw new Error("Parse checkpoint is missing");
  render({ ...route, phase: "parse" }, "Parsing supported documents\u2026");
  const response = await chrome.runtime.sendMessage({
    contractVersion: CONTRACT_VERSION,
    type: "START_PARSE",
    scanId: route.scanId
  });
  if (!isRecord(response) || typeof response.error === "string" || !isRecord(response.state)) {
    throw scanErrorFrom(response, "Parse failed");
  }
  const state = parseParseState(response.state);
  if (!state) throw new Error("Parse returned an invalid state");
  render(
    { ...route, state: "scanning", phase: "normalize" },
    `Parse Complete \xB7 ${String(state.parsed)} parsed \xB7 ${String(state.partial)} partial \xB7 ${String(state.unsupported)} unsupported \xB7 ${String(state.failed)} failed`,
    false,
    null,
    state
  );
}
async function beginNormalize(route) {
  if (!route.scanId) throw new Error("Normalize checkpoint is missing");
  render({ ...route, phase: "normalize" }, "Normalizing evidence\u2026");
  const response = await chrome.runtime.sendMessage({
    contractVersion: CONTRACT_VERSION,
    type: "START_NORMALIZE",
    scanId: route.scanId
  });
  if (!isRecord(response) || typeof response.error === "string" || !isRecord(response.state)) {
    throw scanErrorFrom(response, "Normalize failed");
  }
  const state = parseNormalizeState(response.state);
  if (!state) throw new Error("Normalize returned an invalid state");
  render(
    { ...route, state: "scanning", phase: "extract" },
    `Normalize Complete \xB7 ${String(state.unitCount)} units \xB7 ${String(state.sourceCount)} sources \xB7 ${String(state.duplicateCount)} duplicates`
  );
}
async function beginExtraction(route) {
  if (!route.scanId) throw new Error("Extraction checkpoint is missing");
  render({ ...route, phase: "extract" }, "Extracting candidate facts\u2026");
  const response = await chrome.runtime.sendMessage({
    contractVersion: CONTRACT_VERSION,
    type: "START_EXTRACTION",
    scanId: route.scanId
  });
  if (!isRecord(response) || typeof response.error === "string" || !isRecord(response.state)) {
    throw scanErrorFrom(response, "Extraction failed");
  }
  const candidateCount = typeof response.state.candidateCount === "number" ? response.state.candidateCount : 0;
  const failedBatchCount = typeof response.state.failedBatchCount === "number" ? response.state.failedBatchCount : 0;
  const failureCodes = Array.isArray(response.state.failureCodes) ? response.state.failureCodes.filter((code) => typeof code === "string") : [];
  if (candidateCount === 0 && failedBatchCount > 0) {
    render(
      { ...route, state: "scanning", phase: "extract" },
      `Extraction Failed \xB7 ${String(failedBatchCount)} failed batches \xB7 ${failureCodes.join(", ") || "AI_BACKEND_FAILED"}`
    );
    return;
  }
  if (candidateCount > 0) {
    render(
      { surface: "review", courseId: route.courseId, scanId: route.scanId },
      "Loading Review\u2026"
    );
  } else {
    render(
      { surface: "course-brief", courseId: route.courseId },
      "No items detected in supported sources"
    );
  }
}
async function persistReview(route, candidates) {
  const progress = reviewProgress(route.scanId, candidates);
  await new IndexedDbReviewRepository().save(route.scanId, candidates, progress);
  const briefRepository = new IndexedDbBriefRepository();
  const existingItems = await briefRepository.listCourseItems(route.courseId);
  const items = briefItemsFromReview(route.courseId, candidates, {}, /* @__PURE__ */ new Date(), existingItems);
  await briefRepository.upsertCourseItems(items);
  const courses = new CourseIndexRepository(chrome.storage.local);
  const course = await courses.findCourse(route.courseId);
  if (course) {
    await courses.upsertCourse({
      ...course,
      hasBrief: course.hasBrief || items.length > 0,
      pendingReviewCount: progress.detected + progress.needsReview
    });
  }
  if (!progress.complete) {
    await appendReview(route, candidates);
    return;
  }
  if (course) {
    await courses.upsertCourse({ ...course, hasBrief: true, pendingReviewCount: 0 });
  }
  render({ surface: "course-brief", courseId: route.courseId }, "Review complete");
}
async function appendReview(route, supplied) {
  const app = document.querySelector("#app");
  if (!app) return;
  const reviewRepository = new IndexedDbReviewRepository();
  const existingBriefItems = await new IndexedDbBriefRepository().listCourseItems(route.courseId);
  const stored = supplied ? null : await reviewRepository.load(route.scanId);
  let candidates = supplied ?? stored?.candidates ?? [];
  let savedProgress = stored?.progress ?? reviewProgress(route.scanId, candidates);
  if (!supplied && stored && savedProgress.reviewed === 0) {
    const merged = mergeCandidateRecords(candidates);
    if (JSON.stringify(merged) !== JSON.stringify(candidates)) {
      candidates = merged;
      savedProgress = reviewProgress(route.scanId, candidates);
      await reviewRepository.save(route.scanId, candidates, savedProgress);
      const courses = new CourseIndexRepository(chrome.storage.local);
      const course = await courses.findCourse(route.courseId);
      if (course) {
        await courses.upsertCourse({
          ...course,
          pendingReviewCount: savedProgress.detected + savedProgress.needsReview
        });
      }
    }
  }
  app.querySelector(".review-content")?.remove();
  const content = document.createElement("div");
  content.className = "review-content";
  if (savedProgress.reviewed === 0) {
    const retry = document.createElement("button");
    retry.type = "button";
    retry.className = "secondary-action";
    retry.textContent = "Retry extraction";
    retry.addEventListener("click", () => {
      retry.disabled = true;
      void beginExtraction({
        surface: "scan",
        state: "scanning",
        courseId: route.courseId,
        scanId: route.scanId,
        phase: "extract"
      }).catch((error) => {
        render(route, error instanceof Error ? error.message : "Extraction retry failed");
      });
    });
    content.append(retry);
  }
  for (const section of ["NeedsReview", "Detected"]) {
    const heading = document.createElement("h2");
    heading.textContent = section === "NeedsReview" ? "Needs Review" : "Detected";
    content.append(heading);
    const sectionCandidates = candidates.filter((candidate) => candidate.status === section);
    if (sectionCandidates.length === 0) {
      const empty = document.createElement("p");
      empty.className = "empty-state";
      empty.textContent = "No items in this section.";
      content.append(empty);
      continue;
    }
    if (section === "Detected") {
      for (const category of ["assessment", "important_date", "important_rule"]) {
        if (!sectionCandidates.some((candidate) => candidate.kind === category)) continue;
        const confirmAll = document.createElement("button");
        confirmAll.type = "button";
        confirmAll.className = "secondary-action";
        confirmAll.textContent = `Confirm all ${category.replace("_", " ")}`;
        confirmAll.addEventListener("click", () => {
          void persistReview(route, confirmDetectedCategory(candidates, category));
        });
        content.append(confirmAll);
      }
    }
    for (const candidate of sectionCandidates) {
      const card = document.createElement("article");
      card.className = "review-card";
      const title = document.createElement("h3");
      title.textContent = candidate.kind.replace("_", " ");
      const value = document.createElement("pre");
      value.textContent = JSON.stringify(candidate.proposedValue, null, 2);
      const relationshipLabel = candidateRelationshipLabel(candidate, candidates);
      const relationship = document.createElement("p");
      relationship.className = "relationship-context";
      relationship.textContent = relationshipLabel ?? "";
      const reviewReason = document.createElement("p");
      reviewReason.className = "unresolved-field";
      reviewReason.textContent = candidate.reviewReason ?? "";
      const actions = document.createElement("div");
      actions.className = "review-actions";
      const action = (label, handler) => {
        const button = document.createElement("button");
        button.type = "button";
        button.className = "secondary-action";
        button.textContent = label;
        button.addEventListener("click", handler);
        return button;
      };
      const relationshipParentExists = candidate.scope === "assessment" && candidate.appliesToAssessmentKey !== void 0 && (candidates.some(
        (item) => item.kind === "assessment" && item.semanticKey === candidate.appliesToAssessmentKey
      ) || existingBriefItems.some(
        (item) => item.kind === "assessment" && item.semanticKey === candidate.appliesToAssessmentKey
      ));
      if (candidate.kind !== "assessment" && (!candidate.scope || !relationshipParentExists)) {
        const candidateParents = candidates.filter((item) => item.kind === "assessment").map((parent) => ({
          semanticKey: parent.semanticKey,
          value: parent.proposedValue
        }));
        const existingParents = existingBriefItems.filter(
          (item) => item.kind === "assessment" && item.semanticKey && !candidateParents.some((parent) => parent.semanticKey === item.semanticKey)
        ).map((parent) => ({
          semanticKey: parent.semanticKey,
          value: parent.currentValue
        }));
        for (const parent of [...candidateParents, ...existingParents]) {
          const parentLabel = typeof parent.value.identifier === "string" ? parent.value.identifier : typeof parent.value.name === "string" ? parent.value.name : parent.semanticKey.replace(/^assessment:/, "").toUpperCase();
          actions.append(
            action(`Applies to ${parentLabel}`, () => {
              void persistReview(
                route,
                assignCandidateRelationship(
                  candidates,
                  candidate.candidateId,
                  "assessment",
                  parent.semanticKey
                )
              );
            })
          );
        }
        actions.append(
          action("Course-level", () => {
            void persistReview(
              route,
              assignCandidateRelationship(candidates, candidate.candidateId, "course")
            );
          })
        );
      }
      actions.append(
        action(
          "Confirm",
          () => void persistReview(route, confirmCandidate(candidates, candidate.candidateId))
        ),
        action("Edit", () => {
          const edited = window.prompt(
            "Edit the confirmed JSON value",
            JSON.stringify(candidate.proposedValue)
          );
          if (!edited) return;
          try {
            const value2 = JSON.parse(edited);
            if (!isRecord(value2)) throw new Error("Value must be an object");
            void persistReview(
              route,
              editAndConfirmCandidate(candidates, candidate.candidateId, value2)
            );
          } catch {
            window.alert("Enter a valid JSON object.");
          }
        }),
        action(
          "Ignore",
          () => void persistReview(route, ignoreCandidate(candidates, candidate.candidateId))
        ),
        action("Skip for now", () => void 0),
        action("View source", () => {
          const evidence = document.createElement("p");
          evidence.className = "evidence";
          evidence.textContent = candidate.evidenceRefs.map((reference) => `${reference.sourceId} \xB7 ${reference.locator}`).join("\n");
          card.append(evidence);
        })
      );
      card.append(title, value);
      if (relationshipLabel) card.append(relationship);
      if (candidate.reviewReason) card.append(reviewReason);
      card.append(actions);
      content.append(card);
    }
  }
  const progress = reviewProgress(route.scanId, candidates);
  const status = app.querySelector(".status-text");
  if (status)
    status.textContent = `${String(progress.reviewed)} of ${String(progress.total)} reviewed`;
  app.insertBefore(content, app.querySelector(".status"));
}
async function applyPermission(route, state, requestAccess) {
  if (!route.scanId || !state.pendingOrigin) throw new Error("Permission request is unavailable");
  const { origin, permissionPattern } = state.pendingOrigin;
  const granted = requestAccess ? await chrome.permissions.request({ origins: [permissionPattern] }) : false;
  const response = await chrome.runtime.sendMessage({
    contractVersion: CONTRACT_VERSION,
    type: "APPLY_PERMISSION_DECISION",
    scanId: route.scanId,
    origin,
    granted
  });
  if (!isRecord(response) || typeof response.error === "string") {
    throw scanErrorFrom(response, "Permission decision could not be saved");
  }
  const nextState = parseFetchState(response.state);
  const waiting = response.outcome === "WaitingForPermission";
  render(
    {
      ...route,
      state: waiting ? "waiting-for-permission" : "scanning",
      phase: waiting ? "fetch" : "parse"
    },
    waiting ? "Another attachment host needs a decision" : fetchStateLabel(response.outcome, nextState),
    false,
    nextState
  );
}
async function beginDiscovery(route) {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  const tabId = tabs[0]?.id;
  if (tabId === void 0) throw new Error("No active NTU Learn tab is available");
  render({ ...route, state: "scanning" }, "Starting course discovery\u2026");
  const response = await chrome.runtime.sendMessage({
    contractVersion: CONTRACT_VERSION,
    type: "START_DISCOVERY",
    courseId: route.courseId,
    tabId,
    ...route.phase === "fetch" && route.scanId ? { restartScanId: route.scanId } : {}
  });
  if (!isRecord(response) || typeof response.error === "string") {
    throw scanErrorFrom(response, "Course discovery could not start");
  }
  const sourceCount = typeof response.sourceCount === "number" ? response.sourceCount : 0;
  const issueCount = typeof response.issueCount === "number" ? response.issueCount : 0;
  const discoveryStatus = typeof response.discoveryStatus === "string" ? response.discoveryStatus : "Unknown";
  const scanId = typeof response.scanId === "string" ? response.scanId : route.scanId;
  if (!scanId) throw new Error("Discovery did not return a Scan checkpoint");
  render(
    { ...route, state: "scanning", phase: "fetch", scanId },
    `Discovery ${discoveryStatus} \xB7 ${String(sourceCount)} sources \xB7 ${String(issueCount)} issues \xB7 next: Fetch`
  );
}
async function cancelScan(route) {
  if (!route.scanId) return;
  const response = await chrome.runtime.sendMessage({
    contractVersion: CONTRACT_VERSION,
    type: "CANCEL_SCAN",
    scanId: route.scanId
  });
  if (!isRecord(response) || response.status !== "Interrupted") {
    throw new Error("Scan could not be cancelled");
  }
  render(
    { ...route, state: "interrupted" },
    "Scan interrupted. Your existing Course Brief is unchanged."
  );
}
async function appendScanIssues(scanId) {
  const app = document.querySelector("#app");
  if (!app) return;
  app.querySelector(".scan-issues")?.remove();
  const response = await chrome.runtime.sendMessage({
    contractVersion: CONTRACT_VERSION,
    type: "GET_SCAN_OVERVIEW",
    scanId
  });
  const issues = isRecord(response) && Array.isArray(response.issues) ? response.issues : [];
  const container = document.createElement("section");
  container.className = "scan-issues";
  const heading = document.createElement("h2");
  heading.textContent = "Scan issues";
  container.append(heading);
  if (issues.length === 0) {
    container.append("No source issues recorded.");
  } else {
    const list = document.createElement("ul");
    for (const issue of issues) {
      if (!isRecord(issue)) continue;
      const item = document.createElement("li");
      item.textContent = `${String(issue.reason)}${typeof issue.sourceId === "string" ? ` \xB7 ${issue.sourceId}` : ""} \xB7 ${String(issue.detail)}${issue.retryable === false ? " \xB7 No retry" : ""}`;
      list.append(item);
    }
    container.append(list);
  }
  app.insertBefore(container, app.querySelector(".status"));
}
async function readDiscoverySummary(scanId) {
  const response = await chrome.runtime.sendMessage({
    contractVersion: CONTRACT_VERSION,
    type: "GET_DISCOVERY_SUMMARY",
    scanId
  });
  if (!isRecord(response) || !isRecord(response.summary)) return null;
  const summary = response.summary;
  const numberValue = (key) => typeof summary[key] === "number" ? summary[key] : 0;
  return {
    label: [
      `Discovery ${summary.complete === true ? "Complete" : "checkpoint"}`,
      `${String(numberValue("sourceCount"))} sources`,
      `${String(numberValue("issueCount"))} issues`,
      `${String(numberValue("contentPageCount"))} content pages`,
      `${String(numberValue("contentDetailCount"))} content details`,
      `${String(numberValue("announcementPageCount"))} announcement pages`,
      `max content depth ${String(numberValue("contentMaxDepth"))}`,
      `${String(numberValue("assignmentCount"))} assignments`,
      `${String(numberValue("announcementCount"))} announcements`,
      `${String(numberValue("attachmentCount"))} attachments`,
      `${String(numberValue("attachmentsMissingRequestUrl"))} attachment URLs pending refresh`,
      `attachment origins ${Array.isArray(summary.attachmentOrigins) ? summary.attachmentOrigins.join(", ") || "none" : "unknown"}`,
      `pagination ${summary.paginationDetected === true ? "observed" : "not observed"}`
    ].join(" \xB7 "),
    needsRefresh: summary.detailCoverageComplete !== true || typeof summary.attachmentsMissingRequestUrl === "number" && summary.attachmentsMissingRequestUrl > 0
  };
}
function render(route, routeLabel, allowCoverageRefresh = false, fetchState = null, parseState = null) {
  const active = route.surface;
  const app = document.querySelector("#app");
  if (!app) throw new Error("Popup root is missing");
  app.replaceChildren();
  const copy = viewCopy(route);
  const header = document.createElement("header");
  header.className = "masthead";
  const brand = document.createElement("div");
  brand.className = "brand-mark";
  brand.setAttribute("aria-hidden", "true");
  brand.textContent = "S";
  const headingGroup = document.createElement("div");
  headingGroup.className = "heading-group";
  const eyebrow = document.createElement("p");
  eyebrow.className = "eyebrow";
  eyebrow.textContent = "Syllab / NTU Learn";
  const title = document.createElement("h1");
  title.textContent = copy.title;
  headingGroup.append(eyebrow, title);
  header.append(brand, headingGroup);
  const lede = document.createElement("p");
  lede.className = "lede";
  lede.textContent = copy.lede;
  const list = document.createElement("ul");
  list.className = "surface-list";
  list.setAttribute("aria-label", "Syllab sections");
  for (const surface of surfaces) {
    const item = document.createElement("li");
    const button = document.createElement("button");
    button.type = "button";
    button.textContent = surface.label;
    button.setAttribute("aria-current", surface.id === active ? "page" : "false");
    button.disabled = surface.id !== active;
    item.append(button);
    list.append(item);
  }
  const status = document.createElement("p");
  status.className = "status";
  const statusLabel = document.createElement("span");
  statusLabel.className = "status-label";
  statusLabel.textContent = copy.statusLabel;
  const statusText = document.createElement("span");
  statusText.className = "status-text";
  statusText.textContent = routeLabel;
  status.append(statusLabel, statusText);
  app.append(header, lede, list);
  if (route.surface === "scan" && route.state === "ready") {
    const action = document.createElement("button");
    action.type = "button";
    action.className = "primary-action";
    action.textContent = "Scan this course";
    action.addEventListener("click", () => {
      action.disabled = true;
      void beginDiscovery(route).catch((error) => {
        render(route, error instanceof Error ? error.message : "Discovery could not start");
      });
    });
    app.append(action);
  }
  if (route.surface === "scan" && route.state === "scanning") {
    const tasks = document.createElement("ol");
    tasks.className = "task-list";
    const taskLabels = [
      "Finding course pages",
      "Finding announcements",
      "Finding assignments",
      "Preparing documents",
      "Extracting course information"
    ];
    for (const [index, task] of taskLabels.entries()) {
      const item = document.createElement("li");
      const completedTasks = route.phase === "normalize" || route.phase === "extract" ? 4 : route.phase === "parse" || route.phase === "fetch" ? 3 : 0;
      item.dataset.state = index < completedTasks ? "complete" : index === completedTasks ? "active" : "pending";
      item.textContent = task;
      tasks.append(item);
    }
    app.append(tasks);
    if (route.scanId) {
      const cancel = document.createElement("button");
      cancel.type = "button";
      cancel.className = "secondary-action";
      cancel.textContent = "Cancel scan";
      cancel.addEventListener("click", () => {
        cancel.disabled = true;
        void cancelScan(route).catch((error) => {
          render(route, error instanceof Error ? error.message : "Scan could not be cancelled");
        });
      });
      app.append(cancel);
    }
    if (route.phase === "fetch" && !allowCoverageRefresh) {
      const action = document.createElement("button");
      action.type = "button";
      action.className = "primary-action";
      action.textContent = "Continue to fetch";
      action.addEventListener("click", () => {
        action.disabled = true;
        void beginFetch(route).catch((error) => {
          render(route, error instanceof Error ? error.message : "Source fetch could not start");
        });
      });
      app.append(action);
    } else if (route.phase === "parse" && fetchState?.suspiciousCount) {
      const action = document.createElement("button");
      action.type = "button";
      action.className = "primary-action";
      action.textContent = "Verify fetched files";
      action.addEventListener("click", () => {
        action.disabled = true;
        void beginFetch(route).catch((error) => {
          render(
            route,
            error instanceof Error ? error.message : "Fetched files could not be verified",
            false,
            fetchState
          );
        });
      });
      app.append(action);
    } else if (route.phase === "parse") {
      const action = document.createElement("button");
      action.type = "button";
      action.className = "primary-action";
      action.textContent = "Continue to parse";
      action.addEventListener("click", () => {
        action.disabled = true;
        void beginParse(route).catch((error) => {
          render(route, error instanceof Error ? error.message : "Parse failed");
        });
      });
      app.append(action);
    } else if (route.phase === "normalize") {
      const continueToNormalize = document.createElement("button");
      continueToNormalize.type = "button";
      continueToNormalize.className = parseState?.failed ? "secondary-action" : "primary-action";
      continueToNormalize.textContent = parseState?.failed ? "Continue with partial results" : "Continue to normalize";
      continueToNormalize.addEventListener("click", () => {
        continueToNormalize.disabled = true;
        void beginNormalize(route).catch((error) => {
          render(route, error instanceof Error ? error.message : "Normalize failed");
        });
      });
      if (parseState?.failed) {
        const retry = document.createElement("button");
        retry.type = "button";
        retry.className = "primary-action";
        retry.textContent = "Retry failed parsing";
        retry.addEventListener("click", () => {
          retry.disabled = true;
          void beginParse(route).catch((error) => {
            render(route, error instanceof Error ? error.message : "Parse retry failed");
          });
        });
        app.append(retry, continueToNormalize);
      } else {
        app.append(continueToNormalize);
      }
    } else if (route.phase === "extract") {
      const action = document.createElement("button");
      action.type = "button";
      action.className = "primary-action";
      action.textContent = "Extract course information";
      action.addEventListener("click", () => {
        action.disabled = true;
        void beginExtraction(route).catch((error) => {
          render(route, error instanceof Error ? error.message : "Extraction failed");
        });
      });
      app.append(action);
    } else if (route.phase === "discovery" || allowCoverageRefresh) {
      const action = document.createElement("button");
      action.type = "button";
      action.className = "primary-action";
      action.textContent = allowCoverageRefresh ? "Refresh discovery coverage" : "Continue discovery";
      action.addEventListener("click", () => {
        action.disabled = true;
        void beginDiscovery(route).catch((error) => {
          render(route, error instanceof Error ? error.message : "Discovery could not continue");
        });
      });
      app.append(action);
    }
  }
  if (route.surface === "scan" && route.state === "interrupted") {
    const interruptedScanId = route.scanId;
    const continueScan = document.createElement("button");
    continueScan.type = "button";
    continueScan.className = "primary-action";
    continueScan.textContent = "Continue scan";
    continueScan.disabled = !interruptedScanId;
    continueScan.addEventListener("click", () => {
      if (!interruptedScanId) return;
      continueScan.disabled = true;
      void chrome.runtime.sendMessage({
        contractVersion: CONTRACT_VERSION,
        type: "RESUME_SCAN",
        scanId: interruptedScanId
      }).then((response) => {
        if (!isRecord(response) || response.status !== "Scanning") {
          throw scanErrorFrom(response, "Scan could not resume");
        }
        render({ ...route, state: "scanning" }, "Continue from the saved checkpoint");
      }).catch((error) => {
        render(route, error instanceof Error ? error.message : "Scan could not resume");
      });
    });
    const tryAgain = document.createElement("button");
    tryAgain.type = "button";
    tryAgain.className = "secondary-action";
    tryAgain.textContent = "Try again from the beginning";
    tryAgain.addEventListener("click", () => {
      void beginDiscovery({ surface: "scan", state: "ready", courseId: route.courseId }).catch(
        (error) => render(route, error instanceof Error ? error.message : "A new scan could not start")
      );
    });
    app.append(continueScan, tryAgain);
  }
  if (route.surface === "scan" && route.state === "waiting-for-permission") {
    if (fetchState?.pendingOrigin) {
      const origin = document.createElement("p");
      origin.className = "permission-origin";
      origin.textContent = `${fetchState.pendingOrigin.origin} \xB7 ${String(fetchState.pendingOrigin.sourceCount)} source${fetchState.pendingOrigin.sourceCount === 1 ? "" : "s"}`;
      const actions = document.createElement("div");
      actions.className = "permission-actions";
      const allow = document.createElement("button");
      allow.type = "button";
      allow.className = "primary-action";
      allow.textContent = "Allow access";
      const deny = document.createElement("button");
      deny.type = "button";
      deny.className = "secondary-action";
      deny.textContent = "Continue without them";
      for (const [button, requestAccess] of [
        [allow, true],
        [deny, false]
      ]) {
        button.addEventListener("click", () => {
          allow.disabled = true;
          deny.disabled = true;
          void applyPermission(route, fetchState, requestAccess).catch((error) => {
            render(
              route,
              error instanceof Error ? error.message : "Permission decision failed",
              false,
              fetchState
            );
          });
        });
      }
      actions.append(allow, deny);
      app.append(origin, actions);
    }
  }
  app.append(status);
  if (route.surface === "review") void appendReview(route);
  if (route.surface === "course-brief") void appendCourseBrief(route.courseId);
  if (route.surface === "saved-courses") void appendSavedCourses();
  if (route.surface === "scan" && route.scanId) {
    const issues = document.createElement("button");
    issues.type = "button";
    issues.className = "secondary-action";
    issues.textContent = "View issues";
    issues.addEventListener("click", () => void appendScanIssues(route.scanId ?? ""));
    app.insertBefore(issues, status);
  }
}
async function appendSavedCourses() {
  const app = document.querySelector("#app");
  if (!app) return;
  app.querySelector(".saved-courses-content")?.remove();
  const content = document.createElement("div");
  content.className = "saved-courses-content";
  const courses = await new CourseIndexRepository(chrome.storage.local).listCourses();
  if (courses.length === 0) {
    const empty = document.createElement("p");
    empty.className = "empty-state";
    empty.textContent = "No saved courses yet. Open an NTU Learn course to start a scan.";
    content.append(empty);
  }
  for (const course of courses) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "saved-course-card";
    button.textContent = `${course.courseCode ?? course.courseName ?? course.courseId}${course.pendingReviewCount ? ` \xB7 ${String(course.pendingReviewCount)} to review` : ""}`;
    button.addEventListener("click", () => {
      render({ surface: "course-brief", courseId: course.courseId }, "Saved course");
    });
    content.append(button);
  }
  app.insertBefore(content, app.querySelector(".status"));
}
async function appendCourseBrief(courseId) {
  const app = document.querySelector("#app");
  if (!app) return;
  app.querySelector(".brief-content")?.remove();
  const content = document.createElement("div");
  content.className = "brief-content";
  const briefRepository = new IndexedDbBriefRepository();
  const courseRepository = new CourseIndexRepository(chrome.storage.local);
  const [items, course] = await Promise.all([
    briefRepository.listCourseItems(courseId),
    courseRepository.findCourse(courseId)
  ]);
  const promptValue = (message, initial = {}) => {
    const response = window.prompt(message, JSON.stringify(initial));
    if (!response) return null;
    try {
      const value = JSON.parse(response);
      if (!isRecord(value)) throw new Error("Value must be an object");
      return value;
    } catch {
      window.alert("Enter a valid JSON object.");
      return null;
    }
  };
  const saveItems = async (next) => {
    await briefRepository.replaceCourseItems(courseId, next);
    await appendCourseBrief(courseId);
  };
  const exportableEvents = calendarEventsFromBrief(items);
  if (exportableEvents.length > 0) {
    const calendar = document.createElement("section");
    calendar.className = "calendar-export";
    const heading = document.createElement("h2");
    heading.textContent = "Calendar export";
    const selected = new Set(exportableEvents.map((event) => event.eventId));
    calendar.append(heading);
    for (const event of exportableEvents) {
      const label = document.createElement("label");
      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.checked = true;
      checkbox.addEventListener("change", () => {
        if (checkbox.checked) selected.add(event.eventId);
        else selected.delete(event.eventId);
      });
      label.append(
        checkbox,
        ` ${event.title} \xB7 ${event.date}${event.time ? ` ${event.time}` : ""}`
      );
      calendar.append(label);
    }
    const selectNone = document.createElement("button");
    selectNone.type = "button";
    selectNone.className = "secondary-action";
    selectNone.textContent = "Select none";
    selectNone.addEventListener("click", () => {
      selected.clear();
      calendar.querySelectorAll('input[type="checkbox"]').forEach((checkbox) => {
        checkbox.checked = false;
      });
    });
    const download = document.createElement("button");
    download.type = "button";
    download.className = "primary-action";
    download.textContent = "Export .ics";
    download.addEventListener("click", () => {
      const chosen = exportableEvents.filter((event) => selected.has(event.eventId));
      if (chosen.length === 0) return;
      const blob = new Blob([serializeCalendar(courseId, chosen)], {
        type: "text/calendar;charset=utf-8"
      });
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = `${course?.courseCode ?? courseId}-syllab.ics`;
      anchor.click();
      setTimeout(() => URL.revokeObjectURL(url), 0);
    });
    calendar.append(selectNone, download);
    content.append(calendar);
  }
  const scanAgain = document.createElement("button");
  scanAgain.type = "button";
  scanAgain.className = "secondary-action";
  scanAgain.textContent = "Scan again";
  scanAgain.addEventListener("click", () => {
    void beginDiscovery({ surface: "scan", state: "ready", courseId }).catch(
      (error) => render(
        { surface: "course-brief", courseId },
        error instanceof Error ? error.message : "A new scan could not start"
      )
    );
  });
  content.append(scanAgain);
  if (course?.pendingReviewCount && course.lastEffectiveScanId) {
    const pending = document.createElement("p");
    pending.className = "unresolved-field";
    pending.textContent = `${String(course.pendingReviewCount)} items need review`;
    const continueReview = document.createElement("button");
    continueReview.type = "button";
    continueReview.className = "secondary-action";
    continueReview.textContent = "Continue review";
    continueReview.addEventListener("click", () => {
      render(
        { surface: "review", courseId, scanId: course.lastEffectiveScanId ?? "" },
        "Review progress"
      );
    });
    content.append(pending, continueReview);
  }
  if (items.length === 0 && !course?.pendingReviewCount) {
    const empty = document.createElement("p");
    empty.className = "empty-state";
    empty.textContent = "No items detected in the supported sources. This does not mean the course has no information.";
    content.append(empty);
    if (course?.lastEffectiveScanId) {
      const scanId = course.lastEffectiveScanId;
      const retry = document.createElement("button");
      retry.type = "button";
      retry.className = "secondary-action";
      retry.textContent = "Retry extraction";
      retry.addEventListener("click", () => {
        retry.disabled = true;
        void beginExtraction({
          surface: "scan",
          state: "scanning",
          courseId,
          scanId,
          phase: "extract"
        }).catch((error) => {
          render(
            { surface: "course-brief", courseId },
            error instanceof Error ? error.message : "Extraction retry failed"
          );
        });
      });
      content.append(retry);
    }
  } else if (items.length === 0) {
    const empty = document.createElement("p");
    empty.className = "empty-state";
    empty.textContent = "Confirmed course facts will appear here as you review them.";
    content.append(empty);
  }
  const topLevelItems = items.filter((item) => !item.parentBriefItemId);
  for (const category of ["assessment", "important_date", "important_rule"]) {
    const section = document.createElement("section");
    section.className = "brief-section";
    const sectionHeading = document.createElement("h2");
    sectionHeading.textContent = category === "assessment" ? "Assessments" : category === "important_date" ? "Other Important Dates" : "Important Rules";
    const add = document.createElement("button");
    add.type = "button";
    add.className = "secondary-action";
    add.textContent = `Add ${category.replace("_", " ")}`;
    add.addEventListener("click", () => {
      const value = promptValue(`Add ${category.replace("_", " ")} as JSON`);
      if (value) void saveItems(addUserBriefItem(items, courseId, category, value));
    });
    section.append(sectionHeading, add);
    for (const item of topLevelItems.filter((current) => current.kind === category)) {
      const card = document.createElement("article");
      card.className = "brief-card";
      const value = document.createElement("pre");
      value.textContent = JSON.stringify(item.currentValue, null, 2);
      const edit = document.createElement("button");
      edit.type = "button";
      edit.className = "secondary-action";
      edit.textContent = "Edit";
      edit.addEventListener("click", () => {
        const edited = promptValue("Edit the confirmed JSON value", item.currentValue);
        if (edited) void saveItems(editBriefItem(items, item.briefItemId, edited));
      });
      card.append(value, edit);
      for (const [field, state] of Object.entries(item.fieldStates)) {
        if (state.status !== "Unresolved") continue;
        const unresolved = document.createElement("div");
        unresolved.className = "unresolved-field";
        unresolved.append(`${field}: Needs review`);
        for (const option of state.candidateValues ?? []) {
          const choose = document.createElement("button");
          choose.type = "button";
          choose.className = "secondary-action";
          choose.textContent = `Use ${JSON.stringify(option)}`;
          choose.addEventListener("click", () => {
            void saveItems(resolveBriefField(items, item.briefItemId, field, option));
          });
          unresolved.append(choose);
        }
        card.append(unresolved);
      }
      if (item.kind === "assessment") {
        const children = items.filter((child) => child.parentBriefItemId === item.briefItemId);
        for (const child of children) {
          const childContent = document.createElement("section");
          childContent.className = "brief-child";
          const childHeading = document.createElement("h3");
          childHeading.textContent = child.kind === "important_date" ? "Important date" : "Requirement";
          const childValue = document.createElement("pre");
          childValue.textContent = JSON.stringify(child.currentValue, null, 2);
          const childEdit = document.createElement("button");
          childEdit.type = "button";
          childEdit.className = "secondary-action";
          childEdit.textContent = "Edit";
          childEdit.addEventListener("click", () => {
            const edited = promptValue("Edit the confirmed JSON value", child.currentValue);
            if (edited) void saveItems(editBriefItem(items, child.briefItemId, edited));
          });
          childContent.append(childHeading, childValue, childEdit);
          if (child.evidenceRefs.length > 0) {
            const childSource = document.createElement("details");
            const childSummary = document.createElement("summary");
            childSummary.textContent = "Source";
            const childEvidence = document.createElement("p");
            childEvidence.className = "evidence";
            childEvidence.textContent = child.evidenceRefs.map((reference) => `${reference.sourceId} \xB7 ${reference.locator}`).join("\n");
            childSource.append(childSummary, childEvidence);
            childContent.append(childSource);
          }
          card.append(childContent);
        }
      }
      if (item.evidenceRefs.length > 0) {
        const source = document.createElement("details");
        const summary = document.createElement("summary");
        summary.textContent = "Source";
        const evidence = document.createElement("p");
        evidence.className = "evidence";
        evidence.textContent = item.evidenceRefs.map((reference) => `${reference.sourceId} \xB7 ${reference.locator}`).join("\n");
        source.append(summary, evidence);
        card.append(source);
      }
      section.append(card);
    }
    content.append(section);
  }
  app.insertBefore(content, app.querySelector(".status"));
}
void resolveCurrentEntry().then(
  async (route) => {
    render(route, `Entry route: ${route.surface}${"state" in route ? ` \xB7 ${route.state}` : ""}`);
    if (route.surface === "scan" && route.scanId) {
      if (route.state === "waiting-for-permission" || route.phase === "parse") {
        const response = await chrome.runtime.sendMessage({
          contractVersion: CONTRACT_VERSION,
          type: "GET_FETCH_STATE",
          scanId: route.scanId
        });
        const state = isRecord(response) ? parseFetchState(response.state) : null;
        render(
          route,
          route.state === "waiting-for-permission" ? "Choose how to handle this attachment host" : fetchStateLabel("Complete", state),
          false,
          state
        );
      } else if (route.phase === "normalize") {
        const response = await chrome.runtime.sendMessage({
          contractVersion: CONTRACT_VERSION,
          type: "GET_PARSE_STATE",
          scanId: route.scanId
        });
        const state = isRecord(response) ? parseParseState(response.state) : null;
        render(
          route,
          state ? `Parse checkpoint \xB7 ${String(state.parsed)} parsed \xB7 ${String(state.partial)} partial \xB7 ${String(state.unsupported)} unsupported \xB7 ${String(state.failed)} failed` : "Parse checkpoint unavailable",
          false,
          null,
          state
        );
      } else if (route.phase === "extract") {
        const response = await chrome.runtime.sendMessage({
          contractVersion: CONTRACT_VERSION,
          type: "GET_NORMALIZE_STATE",
          scanId: route.scanId
        });
        const state = isRecord(response) ? parseNormalizeState(response.state) : null;
        render(
          route,
          state ? `Normalize checkpoint \xB7 ${String(state.unitCount)} units \xB7 ${String(state.sourceCount)} sources \xB7 ${String(state.duplicateCount)} duplicates` : "Normalize checkpoint unavailable"
        );
      } else {
        const summary = await readDiscoverySummary(route.scanId);
        if (summary) render(route, summary.label, summary.needsRefresh);
      }
    }
  },
  () => render({ surface: "saved-courses" }, "Open a course in NTU Learn to begin")
);
//# sourceMappingURL=popup.js.map
